# agro-climatic bulletin

weather-based agricultural advisory system providing farmers with climate information for decision-making

**Aliases:** agro-climatic bulletins

**Frequency:** 5

**Parent:** [[Agroclimatic Advisory Services]]

## Relationships

- targets [[agricultural officer]]
- located_in [[Viet Nam]]
- targets [[agricultural officer]]
- located_in [[Viet Nam]]
