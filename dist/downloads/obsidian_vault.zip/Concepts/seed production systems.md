# seed production systems

organized networks for producing and distributing quality crop seeds

**Frequency:** 3

**Parent:** [[Seed Systems Development]]

## Relationships

- targets [[groundnut]]
- targets [[groundnut]]
