# target product profiles

systematic documentation of desired crop characteristics based on market needs

**Aliases:** target product profile

**Frequency:** 13

**Parent:** [[Innovation Assessment and Bundling]]

## Relationships

- uses [[partnership assessment framework]]
- targets [[Bambara groundnut]]
- uses [[partnership assessment framework]]
- targets [[Bambara groundnut]]

## Referenced By

- [[market segmentation]] uses this
- [[CGIAR]] uses this
- [[market segmentation]] uses this
- [[CGIAR]] uses this
