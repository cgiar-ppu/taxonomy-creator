# Satellite and Remote Sensing Applications

Satellite-based monitoring of environmental and agricultural systems

**Parent:** [[Remote Sensing and Earth Observation for Environment]]

