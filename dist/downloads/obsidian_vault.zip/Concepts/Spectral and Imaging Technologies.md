# Spectral and Imaging Technologies

Hyperspectral, multispectral, and other imaging technologies

**Parent:** [[Remote Sensing and Earth Observation]]

