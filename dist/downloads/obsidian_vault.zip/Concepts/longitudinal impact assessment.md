# longitudinal impact assessment

long-term tracking of intervention effects over multiple time periods

**Frequency:** 1

**Parent:** [[Experimental and Evaluation Methods]]

## Relationships

- located_in [[Western Highlands of Guatemala]]
- located_in [[Western Highlands of Guatemala]]
