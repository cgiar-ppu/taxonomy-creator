# no-till conservation agriculture

farming practice that maintains soil cover and reduces erosion by avoiding tillage

**Frequency:** 1

**Parent:** [[Soil Health and Management]]

## Relationships

- part_of [[Generation Green]]
- part_of [[Generation Green]]
