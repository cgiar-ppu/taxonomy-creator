# community-led environmental management

local community-driven approaches to natural resource management and environmental conservation

**Frequency:** 2

**Parent:** [[Locally Led Approaches]]

