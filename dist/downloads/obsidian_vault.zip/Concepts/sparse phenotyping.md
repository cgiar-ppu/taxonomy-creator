# sparse phenotyping

strategy to reduce phenotyping costs while maintaining selection accuracy

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- addresses [[breeding costs]]
- addresses [[breeding costs]]
