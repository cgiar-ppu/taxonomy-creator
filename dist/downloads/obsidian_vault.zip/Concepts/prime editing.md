# prime editing

precise genome modification technique that enables targeted genetic changes

**Frequency:** 4

**Parent:** [[Crop Genetic Improvement]]

## Relationships

- targets [[potato virus Y]]
- targets [[TaSTP13]]
- targets [[rice blast]]
- uses [[Faro66]]
- targets [[potato virus Y]]
- targets [[TaSTP13]]
- targets [[rice blast]]
- uses [[Faro66]]

## Referenced By

- [[International Potato Center]] uses this
- [[International Potato Center]] uses this
