# responsible scaling

expansion of innovations while anticipating and mitigating social and environmental risks

**Frequency:** 2

**Parent:** [[Scaling Frameworks and Strategies]]

## Relationships

- uses [[whole-farm innovation bundles]]
- uses [[whole-farm innovation bundles]]

## Referenced By

- [[CGIAR Scaling Fund]] uses this
- [[CGIAR Scaling Fund]] uses this
