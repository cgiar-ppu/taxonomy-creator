# policy integration

incorporating innovations into official government frameworks

**Frequency:** 7

**Parent:** [[Integrated and Adaptive Management]]

## Relationships

- produces [[scaling pathways]]
- addresses [[biofortification]]
- produces [[scaling pathways]]
- addresses [[biofortification]]
