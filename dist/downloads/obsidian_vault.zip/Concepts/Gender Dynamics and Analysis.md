# Gender Dynamics and Analysis

Analysis of gender dynamics, norms, and relations

**Parent:** [[Gender and Social Dimensions]]

