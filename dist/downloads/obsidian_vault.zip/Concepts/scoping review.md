# scoping review

systematic research method to map existing literature and identify knowledge gaps

**Frequency:** 1

**Parent:** [[Uncategorized]]

## Relationships

- produces [[evidence base]]
- produces [[evidence base]]
