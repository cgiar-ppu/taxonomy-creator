# circular economy principles

resource management strategies that minimize waste and maximize nutrient retention within production systems

**Frequency:** 1

**Parent:** [[Circular Economy Principles]]

## Relationships

- addresses [[greenhouse gas measurement]]
- addresses [[greenhouse gas measurement]]

## Referenced By

- [[ILRI]] uses this
- [[ILRI]] uses this
