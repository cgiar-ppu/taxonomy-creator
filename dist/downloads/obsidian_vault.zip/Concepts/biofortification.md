# biofortification

enhancing nutritional content of crops through breeding

**Frequency:** 41

**Parent:** [[Nutrition-Sensitive Approaches]]

## Relationships

- produces [[zinc-enriched varieties]]
- addresses [[malnutrition]]
- produces [[high kernel-zinc maize]]
- targets [[Sub-Saharan Africa]]
- targets [[rice]]
- targets [[micronutrient malnutrition]]
- targets [[potato]]
- addresses [[nutritional security]]
- addresses [[hidden hunger]]
- uses [[maize]]
- uses [[rice]]
- targets [[smallholder farmers]]
- uses [[orange-fleshed sweetpotato]]
- uses [[sweet potato]]
- uses [[wheat]]
- addresses [[nutrition-sensitive aquaculture]]
- uses [[orange-fleshed sweet potato]]
- uses [[green grams]]
- targets [[smallholder farmers]]
- is_a [[nutrition-sensitive agriculture]]
- produces [[zinc-enriched varieties]]
- addresses [[malnutrition]]
- produces [[high kernel-zinc maize]]
- targets [[Sub-Saharan Africa]]
- targets [[rice]]
- targets [[micronutrient malnutrition]]
- targets [[potato]]
- addresses [[nutritional security]]
- addresses [[hidden hunger]]
- uses [[maize]]
- uses [[rice]]
- targets [[smallholder farmers]]
- uses [[orange-fleshed sweetpotato]]
- uses [[sweet potato]]
- uses [[wheat]]
- addresses [[nutrition-sensitive aquaculture]]
- uses [[orange-fleshed sweet potato]]
- uses [[green grams]]
- targets [[smallholder farmers]]
- is_a [[nutrition-sensitive agriculture]]

## Referenced By

- [[beans]] uses this
- [[ICTA]] produces this
- [[agricultural intensification]] uses this
- [[pearl millet]] uses this
- [[cowpea]] uses this
- [[maize]] uses this
- [[policy integration]] addresses this
- [[IITA]] uses this
- [[CIP]] uses this
- [[beans]] uses this
- [[ICTA]] produces this
- [[agricultural intensification]] uses this
- [[pearl millet]] uses this
- [[cowpea]] uses this
- [[maize]] uses this
- [[policy integration]] addresses this
- [[IITA]] uses this
- [[CIP]] uses this
