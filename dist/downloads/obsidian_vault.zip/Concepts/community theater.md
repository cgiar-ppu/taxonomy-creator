# community theater

use of theatrical performances and storytelling to raise awareness and promote social change in communities

**Frequency:** 1

**Parent:** [[Training Modalities]]

