# improved seed adoption

process by which farmers take up and use enhanced crop varieties

**Frequency:** 2

**Parent:** [[Technology Adoption and Diffusion]]

## Relationships

- targets [[smallholder farmers]]
- targets [[smallholder farmers]]
