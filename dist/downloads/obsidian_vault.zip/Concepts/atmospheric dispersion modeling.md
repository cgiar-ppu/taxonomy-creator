# atmospheric dispersion modeling

mathematical simulation of how gases spread through the atmosphere

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]


## Referenced By

- [[drone-based monitoring]] uses this
- [[drone-based monitoring]] uses this
