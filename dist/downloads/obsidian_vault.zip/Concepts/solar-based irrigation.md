# solar-based irrigation

water delivery system powered by solar energy for agricultural production

**Frequency:** 2

**Parent:** [[Irrigation and Water Infrastructure]]

## Relationships

- targets [[smallholder farmers]]
- located_in [[Nigeria]]
- targets [[smallholder farmers]]
- located_in [[Nigeria]]
