# climate loss and damage

economic and non-economic losses from climate change impacts that cannot be avoided through adaptation

**Frequency:** 1

**Parent:** [[Miscellaneous Methods and Approaches]]


## Referenced By

- [[Ethiopia]] addresses this
- [[Ethiopia]] addresses this
