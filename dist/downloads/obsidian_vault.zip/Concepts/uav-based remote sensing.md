# uav-based remote sensing

collection of agricultural data using unmanned aerial vehicles equipped with sensors

**Frequency:** 1

**Parent:** [[Remote Sensing and Earth Observation]]


## Referenced By

- [[machine learning phenotyping]] uses this
- [[machine learning phenotyping]] uses this
