# cultural heritage preservation

maintenance of traditional agricultural practices and genetic resources

**Frequency:** 1

**Parent:** [[Traditional and Indigenous Knowledge]]

## Relationships

- located_in [[Cordillera Administrative Region]]
- located_in [[Cordillera Administrative Region]]
