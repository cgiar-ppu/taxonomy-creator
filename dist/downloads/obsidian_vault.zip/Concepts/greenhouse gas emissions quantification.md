# greenhouse gas emissions quantification

systematic measurement and assessment of agricultural greenhouse gas emissions using bottom-up approaches

**Frequency:** 1

**Parent:** [[Greenhouse Gas Measurement and Reporting]]

## Relationships

- addresses [[climate-smart agriculture]]
- addresses [[climate-smart agriculture]]
