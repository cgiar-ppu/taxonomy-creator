# digital phenotyping

automated collection of plant trait data using digital technologies

**Frequency:** 2

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- uses [[drone-based imaging]]
- uses [[drone-based imaging]]
