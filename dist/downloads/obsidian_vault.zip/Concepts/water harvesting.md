# water harvesting

collection and storage of rainwater or surface water for agricultural use

**Frequency:** 1

**Parent:** [[Irrigation and Water Infrastructure]]

## Relationships

- located_in [[Totonicapán]]
- located_in [[Totonicapán]]
