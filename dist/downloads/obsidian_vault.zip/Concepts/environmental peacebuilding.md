# environmental peacebuilding

use of environmental cooperation to promote peace and social cohesion in post-conflict areas

**Frequency:** 2

**Parent:** [[Climate-Conflict Nexus]]

## Relationships

- uses [[nutrition-sensitive agriculture]]
- addresses [[climate security]]
- uses [[nutrition-sensitive agriculture]]
- addresses [[climate security]]

## Referenced By

- [[Alliance of Bioversity International and CIAT]] uses this
- [[Alliance of Bioversity International and CIAT]] uses this
