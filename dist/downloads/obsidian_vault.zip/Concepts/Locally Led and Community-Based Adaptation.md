# Locally Led and Community-Based Adaptation

Community-driven and locally led approaches to climate adaptation

**Parent:** [[Climate Adaptation and Resilience]]

