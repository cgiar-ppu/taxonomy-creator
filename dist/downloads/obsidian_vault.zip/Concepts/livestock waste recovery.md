# livestock waste recovery

conversion of animal manure into useful products like biogas or compost

**Frequency:** 1

**Parent:** [[Uncategorized]]


## Referenced By

- [[circular bioeconomy]] addresses this
- [[circular bioeconomy]] addresses this
