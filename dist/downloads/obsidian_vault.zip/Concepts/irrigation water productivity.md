# irrigation water productivity

measure of crop yield per unit of irrigation water applied

**Frequency:** 2

**Parent:** [[Specialized Analytical Techniques]]


## Referenced By

- [[rice]] produces this
- [[rice]] produces this
