# conflict-affected settings

regions experiencing or recovering from armed conflict or civil unrest

**Frequency:** 2

**Parent:** [[Fragile and Conflict-Affected Settings]]

## Relationships

- located_in [[Ethiopia]]
- located_in [[Ethiopia]]
