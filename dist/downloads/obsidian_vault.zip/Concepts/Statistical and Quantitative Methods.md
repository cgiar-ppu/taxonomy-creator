# Statistical and Quantitative Methods

Statistical analysis and quantitative research methods

**Parent:** [[Economic and Systems Modeling]]

