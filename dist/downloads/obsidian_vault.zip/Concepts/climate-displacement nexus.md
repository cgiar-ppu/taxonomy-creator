# climate-displacement nexus

relationship between climate change impacts and human displacement

**Frequency:** 4

**Parent:** [[Displacement and Migration]]

## Relationships

- located_in [[Honduras]]
- located_in [[Honduras]]

## Referenced By

- [[validation workshops]] addresses this
- [[capacity building]] addresses this
- [[validation workshops]] addresses this
- [[capacity building]] addresses this
