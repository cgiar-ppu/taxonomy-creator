# farmer-to-farmer learning

peer-to-peer knowledge exchange methods that validate farmers as sources of innovation

**Frequency:** 1

**Parent:** [[Participatory Learning Methods]]

## Relationships

- located_in [[North Shewa Zone]]
- located_in [[North Shewa Zone]]
