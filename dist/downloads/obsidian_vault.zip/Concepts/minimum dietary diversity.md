# minimum dietary diversity

indicator measuring consumption across different food groups as proxy for nutrient adequacy

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]


## Referenced By

- [[Diet Quality Questionnaire]] uses this
- [[Diet Quality Questionnaire]] uses this
