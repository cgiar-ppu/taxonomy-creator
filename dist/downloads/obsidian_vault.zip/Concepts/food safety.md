# food safety

assurance that food will not cause harm when prepared or consumed

**Frequency:** 6

**Parent:** [[Miscellaneous Methods and Approaches]]

## Relationships

- addresses [[Salmonella]]
- addresses [[Salmonella]]

## Referenced By

- [[choice experiment]] addresses this
- [[choice experiment]] addresses this
