# Breeding Program Design and Management

Frameworks and processes for organizing and running breeding programs

**Parent:** [[Plant Breeding Methods and Strategies]]

