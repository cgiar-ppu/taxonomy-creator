# water justice

equitable access to water resources and inclusive decision-making in water management

**Frequency:** 1

**Parent:** [[Justice and Equity Frameworks]]

## Relationships

- uses [[distributive justice]]
- uses [[procedural justice]]
- uses [[distributive justice]]
- uses [[procedural justice]]

## Referenced By

- [[Egypt]] uses this
- [[Egypt]] uses this
