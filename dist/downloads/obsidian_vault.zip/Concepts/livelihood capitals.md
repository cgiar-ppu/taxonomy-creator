# livelihood capitals

assets and resources that individuals and households use to build their livelihoods

**Frequency:** 1

**Parent:** [[Livelihoods and Social Welfare]]

