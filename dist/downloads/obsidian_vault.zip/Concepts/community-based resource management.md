# community-based resource management

participatory strategy where local communities manage their natural resources

**Frequency:** 2

**Parent:** [[Governance Frameworks]]

## Relationships

- located_in [[Solomon Islands]]
- addresses [[sustainable development]]
- located_in [[Solomon Islands]]
- addresses [[sustainable development]]
