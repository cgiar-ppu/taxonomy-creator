# cluster randomized controlled trial

experimental design where groups rather than individuals are randomly assigned to treatments

**Frequency:** 1

**Parent:** [[Uncategorized]]

## Relationships

- uses [[gender transformative approaches]]
- uses [[gender transformative approaches]]
