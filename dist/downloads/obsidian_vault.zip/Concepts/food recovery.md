# food recovery

systematic collection and redistribution of surplus food to reduce waste and improve access

**Frequency:** 2

**Parent:** [[Waste-to-Value and Resource Recovery]]

## Relationships

- addresses [[food security]]
- addresses [[food security]]
