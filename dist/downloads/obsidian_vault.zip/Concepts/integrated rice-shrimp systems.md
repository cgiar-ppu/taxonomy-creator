# integrated rice-shrimp systems

farming system combining rice cultivation with shrimp aquaculture in the same field

**Frequency:** 1

**Parent:** [[Integrated Rice-Fish and Aquatic Farming]]

## Relationships

- located_in [[Mekong Delta]]
- located_in [[Mekong Delta]]

## Referenced By

- [[rice]] part_of this
- [[rice]] part_of this
