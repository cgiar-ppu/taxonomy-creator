# urban farming

agricultural production within urban environments to enhance local food security

**Frequency:** 2

**Parent:** [[Urban Farming Systems]]

## Relationships

- located_in [[Quezon City]]
- located_in [[Quezon City]]
