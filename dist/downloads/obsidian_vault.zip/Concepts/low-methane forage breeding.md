# low-methane forage breeding

selection and breeding of feed crops that reduce livestock methane production

**Frequency:** 1

**Parent:** [[Methane and Emission Reduction Practices]]

## Relationships

- addresses [[enteric methane reduction]]
- addresses [[enteric methane reduction]]
