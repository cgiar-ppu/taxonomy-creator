# bioinformatics analysis

computational methods for analyzing biological data, particularly genomic sequences

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- located_in [[CIAT]]
- located_in [[CIAT]]

## Referenced By

- [[low trophic aquaculture]] uses this
- [[low trophic aquaculture]] uses this
