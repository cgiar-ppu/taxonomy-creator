# multistakeholder networks

collaborative structures involving diverse actors to coordinate knowledge sharing and scaling

**Frequency:** 2

**Parent:** [[Multi-Stakeholder Platforms and Partnerships]]

## Relationships

- uses [[innovation scaling]]
- uses [[innovation scaling]]

## Referenced By

- [[participatory research]] uses this
- [[participatory research]] uses this
