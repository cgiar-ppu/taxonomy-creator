# Digital Advisory and Extension Services

Digital tools and platforms for agricultural advisory and extension

**Parent:** [[Agricultural Extension and Advisory Services]]

