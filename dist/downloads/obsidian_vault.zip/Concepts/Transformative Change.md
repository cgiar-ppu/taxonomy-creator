# Transformative Change

Approaches for transformative and systemic change

**Parent:** [[Resilience and Vulnerability]]

