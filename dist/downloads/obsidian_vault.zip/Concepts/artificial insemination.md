# artificial insemination

reproductive technology for controlled breeding in livestock

**Frequency:** 2

**Parent:** [[Livestock Production and Management]]


## Referenced By

- [[transabdominal ultrasonography]] uses this
- [[community-based breeding]] uses this
- [[transabdominal ultrasonography]] uses this
- [[community-based breeding]] uses this
