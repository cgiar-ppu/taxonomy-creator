# food diversity

variety of food types available within a given area or system

**Frequency:** 3

**Parent:** [[Dietary Assessment and Quality]]

## Relationships

- located_in [[Nairobi]]
- located_in [[Nairobi]]
