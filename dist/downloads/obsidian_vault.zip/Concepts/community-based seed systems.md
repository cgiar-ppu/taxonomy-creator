# community-based seed systems

local seed production and distribution networks managed by farming communities

**Frequency:** 1

**Parent:** [[Seed Systems Development]]

## Relationships

- targets [[smallholder farmers]]
- targets [[smallholder farmers]]

## Referenced By

- [[maize]] part_of this
- [[maize]] part_of this
