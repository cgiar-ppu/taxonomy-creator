# tree-based restoration

ecosystem rehabilitation using tree planting and forest regeneration techniques

**Frequency:** 1

**Parent:** [[Sustainable Land Management]]

## Relationships

- uses [[seed systems]]
- uses [[seed systems]]
