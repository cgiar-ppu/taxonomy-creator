# biodiversity integration

incorporation of biological diversity principles into agricultural systems

**Frequency:** 1

**Parent:** [[Biodiversity Conservation]]

## Relationships

- located_in [[Kenya]]
- located_in [[Kenya]]
