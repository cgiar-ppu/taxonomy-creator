# sustainable livestock practices

animal husbandry methods that balance productivity with environmental and social sustainability

**Frequency:** 4

**Parent:** [[Sustainable Intensification and Diversification]]

## Relationships

- located_in [[Olancho]]
- located_in [[Vietnam]]
- located_in [[Honduras]]
- located_in [[Olancho]]
- located_in [[Vietnam]]
- located_in [[Honduras]]

## Referenced By

- [[Heifer International]] uses this
- [[livestock producers]] uses this
- [[Heifer International]] uses this
- [[livestock producers]] uses this
