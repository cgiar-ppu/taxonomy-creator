# private sector investment

mobilization of commercial capital for development and sustainability outcomes

**Frequency:** 4

**Parent:** [[Multi-Stakeholder Platforms and Partnerships]]


## Referenced By

- [[rangeland restoration]] uses this
- [[rangeland restoration]] uses this
