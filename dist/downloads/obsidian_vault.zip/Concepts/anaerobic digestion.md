# anaerobic digestion

biological process that breaks down organic matter in oxygen-free environment to produce biogas

**Frequency:** 1

**Parent:** [[Biogas and Bioenergy]]

## Relationships

- produces [[biomethane potential]]
- addresses [[circular bioeconomy]]
- produces [[biomethane potential]]
- addresses [[circular bioeconomy]]

## Referenced By

- [[co-digestion]] part_of this
- [[co-digestion]] part_of this
