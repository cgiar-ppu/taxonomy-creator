# climate finance mobilization

strategies to attract and deploy financial resources for climate adaptation and mitigation

**Frequency:** 1

**Parent:** [[Climate Finance]]

