# malnutrition forecasting

predictive modeling to anticipate acute child malnutrition for early warning systems

**Frequency:** 1

**Parent:** [[Miscellaneous Methods and Approaches]]

