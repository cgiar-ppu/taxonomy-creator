# conditional subsidies

financial incentives tied to specific agricultural practices or outcomes

**Frequency:** 1

**Parent:** [[Social Protection in Fragile Contexts]]


## Referenced By

- [[agroecology]] uses this
- [[agroecology]] uses this
