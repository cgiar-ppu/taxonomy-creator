# nationally determined contributions

country-specific climate action plans under the Paris Agreement

**Frequency:** 20

**Parent:** [[Miscellaneous Methods and Approaches]]

## Relationships

- located_in [[Bangladesh]]
- located_in [[Uganda]]
- addresses [[climate justice]]
- part_of [[Paris Agreement]]
- located_in [[West Africa]]
- part_of [[Paris Agreement]]
- uses [[UAE-Belém Framework]]
- located_in [[Bangladesh]]
- located_in [[Uganda]]
- addresses [[climate justice]]
- part_of [[Paris Agreement]]
- located_in [[West Africa]]
- part_of [[Paris Agreement]]
- uses [[UAE-Belém Framework]]

## Referenced By

- [[aquatic food systems]] part_of this
- [[civil society engagement]] addresses this
- [[aquatic food systems]] part_of this
- [[civil society engagement]] addresses this
