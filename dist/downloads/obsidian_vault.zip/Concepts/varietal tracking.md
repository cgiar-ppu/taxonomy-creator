# varietal tracking

monitoring adoption and distribution of specific crop varieties

**Frequency:** 1

**Parent:** [[Seed Systems Development]]

## Relationships

- located_in [[Tanzania]]
- located_in [[Tanzania]]

## Referenced By

- [[SNP markers]] uses this
- [[SNP markers]] uses this
