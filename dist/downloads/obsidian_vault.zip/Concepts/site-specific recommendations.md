# site-specific recommendations

tailored agricultural advice based on local conditions and farmer circumstances

**Frequency:** 5

**Parent:** [[Agroclimatic Advisory Services]]


## Referenced By

- [[RiceAdvice]] produces this
- [[RiceAdvice]] produces this
- [[Inland Valley Suitability tool]] uses this
- [[RiceAdvice]] produces this
- [[RiceAdvice]] produces this
- [[Inland Valley Suitability tool]] uses this
