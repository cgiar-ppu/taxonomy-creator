# drought tolerance breeding

development of varieties adapted to water-limited conditions

**Frequency:** 2

**Parent:** [[Crop Genetic Improvement]]

