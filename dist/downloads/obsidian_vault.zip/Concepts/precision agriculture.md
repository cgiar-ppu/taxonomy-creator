# precision agriculture

data-driven farming approach using technology for site-specific crop management

**Frequency:** 13

**Parent:** [[Precision Farming Technologies]]

## Relationships

- uses [[artificial intelligence]]
- uses [[generative artificial intelligence]]
- uses [[direct seeded rice]]
- uses [[hyperspectral remote sensing]]
- uses [[satellite-based crop monitoring]]
- uses [[digital agriculture]]
- uses [[artificial intelligence]]
- uses [[generative artificial intelligence]]
- uses [[direct seeded rice]]
- uses [[hyperspectral remote sensing]]
- uses [[satellite-based crop monitoring]]
- uses [[digital agriculture]]

## Referenced By

- [[nitrogen use efficiency]] related_to this
- [[solar irrigation]] addresses this
- [[nitrogen use efficiency]] related_to this
- [[solar irrigation]] addresses this
