# bundled financial services

integrated packages combining credit, insurance, and agricultural services

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- addresses [[climate risk management]]
- located_in [[Meru County]]
- addresses [[climate risk management]]
- located_in [[Meru County]]
