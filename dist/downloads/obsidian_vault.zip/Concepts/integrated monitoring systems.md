# integrated monitoring systems

comprehensive surveillance platforms combining multiple data sources

**Frequency:** 2

**Parent:** [[MRV Frameworks]]

## Relationships

- uses [[Babai Irrigation Information System]]
- uses [[Babai Irrigation Information System]]

## Referenced By

- [[Department of Water Resources and Irrigation]] uses this
- [[Department of Water Resources and Irrigation]] uses this
