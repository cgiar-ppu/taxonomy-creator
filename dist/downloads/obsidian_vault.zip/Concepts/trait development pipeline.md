# trait development pipeline

systematic framework for translating research discoveries into breeding applications

**Frequency:** 1

**Parent:** [[Crop Genetic Improvement]]

## Relationships

- uses [[marker-assisted selection]]
- uses [[marker-assisted selection]]

## Referenced By

- [[IRRI]] produces this
- [[IRRI]] produces this
