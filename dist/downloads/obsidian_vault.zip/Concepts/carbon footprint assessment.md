# carbon footprint assessment

quantification of greenhouse gas emissions from agricultural production systems

**Frequency:** 3

**Parent:** [[Life Cycle and Environmental Assessment]]


## Referenced By

- [[life cycle assessment]] uses this
- [[CLEANED]] uses this
- [[ICRISAT]] uses this
- [[life cycle assessment]] uses this
- [[CLEANED]] uses this
- [[ICRISAT]] uses this
