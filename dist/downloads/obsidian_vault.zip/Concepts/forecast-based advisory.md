# forecast-based advisory

decision support system using weather forecasts to guide agricultural practices

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]

