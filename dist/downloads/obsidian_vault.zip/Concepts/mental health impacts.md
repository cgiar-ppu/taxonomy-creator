# mental health impacts

psychological consequences of climate change and displacement on affected populations

**Frequency:** 2

**Parent:** [[Livelihoods and Social Welfare]]


## Referenced By

- [[forced displacement]] produces this
- [[forced displacement]] produces this
