# integrated aquaculture agriculture

farming system combining fish production with crop cultivation to maximize resource efficiency

**Frequency:** 3

**Parent:** [[Integrated Rice-Fish and Aquatic Farming]]

## Relationships

- located_in [[Egypt]]
- located_in [[Egypt]]

## Referenced By

- [[Nile tilapia]] part_of this
- [[Nile tilapia]] part_of this
