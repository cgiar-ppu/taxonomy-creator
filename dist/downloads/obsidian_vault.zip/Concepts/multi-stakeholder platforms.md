# multi-stakeholder platforms

collaborative spaces bringing together diverse actors for innovation and change

**Aliases:** multi-stakeholder platform

**Frequency:** 33

**Parent:** [[Multi-Stakeholder Platforms and Partnerships]]

## Relationships

- produces [[agroecological transition]]
- uses [[innovation bundling]]
- uses [[evidence-based decision support]]
- addresses [[water conflicts]]
- addresses [[climate-smart agriculture]]
- uses [[knowledge sharing]]
- uses [[adaptive management]]
- part_of [[climate-smart agriculture]]
- produces [[agroecological transition]]
- uses [[innovation bundling]]
- uses [[evidence-based decision support]]
- addresses [[water conflicts]]
- addresses [[climate-smart agriculture]]
- uses [[knowledge sharing]]
- uses [[adaptive management]]
- part_of [[climate-smart agriculture]]

## Referenced By

- [[agroecological transition]] uses this
- [[IWMI]] uses this
- [[Pesira]] uses this
- [[Cambodia]] uses this
- [[scaling pathways]] uses this
- [[participatory diagnosis]] uses this
- [[agroecological transition]] uses this
- [[IWMI]] uses this
- [[Pesira]] uses this
- [[Cambodia]] uses this
- [[scaling pathways]] uses this
- [[participatory diagnosis]] uses this
