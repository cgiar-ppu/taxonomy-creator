# social behavior change communication

strategic communication approach to influence behaviors and social norms

**Frequency:** 4

**Parent:** [[Behavior Change Approaches]]

## Relationships

- targets [[smallholder farmers]]
- located_in [[Son La province]]
- targets [[smallholder farmers]]
- located_in [[Son La province]]
