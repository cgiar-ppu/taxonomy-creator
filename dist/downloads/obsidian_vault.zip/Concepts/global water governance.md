# global water governance

international frameworks and institutions for managing water resources across borders

**Frequency:** 1

**Parent:** [[Miscellaneous Methods and Approaches]]

