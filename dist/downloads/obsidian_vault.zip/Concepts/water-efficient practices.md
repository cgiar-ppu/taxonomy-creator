# water-efficient practices

techniques and methods to optimize water use in agricultural systems

**Frequency:** 2

**Parent:** [[Water Productivity and Efficiency]]


## Referenced By

- [[alternate wetting and drying]] produces this
- [[aquifer recharge zone mapping]] addresses this
- [[alternate wetting and drying]] produces this
- [[aquifer recharge zone mapping]] addresses this
