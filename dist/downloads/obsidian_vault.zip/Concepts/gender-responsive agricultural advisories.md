# gender-responsive agricultural advisories

agricultural guidance systems designed to address different needs and constraints of men and women farmers

**Frequency:** 3

**Parent:** [[Gender-Responsive Programming]]

## Relationships

- targets [[smallholder farmers]]
- targets [[smallholder farmers]]
