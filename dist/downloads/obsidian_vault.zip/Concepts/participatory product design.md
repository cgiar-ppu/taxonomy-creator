# participatory product design

collaborative approach involving stakeholders in identifying market segments and prioritizing traits for product development

**Frequency:** 1

**Parent:** [[Stakeholder Engagement Methods]]

## Relationships

- targets [[value chain stakeholders]]
- targets [[value chain stakeholders]]

## Referenced By

- [[Alliance of Bioversity and CIAT]] uses this
- [[Alliance of Bioversity and CIAT]] uses this
