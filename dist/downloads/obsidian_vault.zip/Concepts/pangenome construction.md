# pangenome construction

assembling comprehensive genomic landscape capturing complete genetic diversity within species

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- uses [[wheat]]
- uses [[wheat]]
