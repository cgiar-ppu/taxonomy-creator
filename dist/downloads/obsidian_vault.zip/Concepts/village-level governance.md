# village-level governance

local institutional arrangements for decision-making and resource management

**Frequency:** 3

**Parent:** [[Governance Frameworks]]

## Relationships

- uses [[carbon accounting]]
- uses [[carbon accounting]]
