# Experimental Preference and Valuation Methods

Methods for eliciting preferences and valuations in experimental settings

**Parent:** [[Experimental and Quasi-Experimental Methods]]

