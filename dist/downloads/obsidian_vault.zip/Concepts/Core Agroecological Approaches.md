# Core Agroecological Approaches

Foundational agroecological and regenerative farming concepts

**Parent:** [[Agroecology and Regenerative Practices]]

