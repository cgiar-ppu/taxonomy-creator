# ultra-poor graduation model

integrated intervention combining cash transfers, assets, training, and coaching for extreme poverty

**Frequency:** 3

**Parent:** [[Social Protection in Fragile Contexts]]

## Relationships

- uses [[cash transfers]]
- uses [[cash transfers]]

## Referenced By

- [[randomized controlled trial]] uses this
- [[randomized controlled trial]] uses this
