# Gender Inclusion and Equity

Gender inclusion, equity, and equality in agricultural development

**Parent:** [[Gender, Social Inclusion, and Empowerment]]

