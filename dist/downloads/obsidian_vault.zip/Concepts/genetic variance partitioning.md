# genetic variance partitioning

statistical decomposition of trait variation into additive and non-additive components

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- targets [[banana]]
- targets [[banana]]
