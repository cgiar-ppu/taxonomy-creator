# randomized control trial

experimental design randomly assigning subjects to treatment and control groups

**Frequency:** 1

**Parent:** [[Uncategorized]]

## Relationships

- uses [[KAZNET]]
- uses [[KAZNET]]
