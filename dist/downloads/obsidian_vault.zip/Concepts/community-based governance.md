# community-based governance

local management systems where communities control and manage shared resources

**Frequency:** 2

**Parent:** [[Miscellaneous Methods and Approaches]]


## Referenced By

- [[Community Fish Refuges]] uses this
- [[Community Fish Refuges]] uses this
