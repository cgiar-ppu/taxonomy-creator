# Agricultural Extension and Advisory Services

Extension services, farmer field demonstrations, digital advisory tools, and community-based extension approaches

**Parent:** [[Capacity Development, Extension, and Knowledge Systems]]

