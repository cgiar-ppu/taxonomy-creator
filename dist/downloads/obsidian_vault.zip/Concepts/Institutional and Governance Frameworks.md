# Institutional and Governance Frameworks

Multi-stakeholder platforms, institutional coordination, and governance for market and value chain development

**Parent:** [[Markets, Value Chains, and Rural Livelihoods]]

