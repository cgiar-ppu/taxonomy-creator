# co-design

collaborative development process involving multiple stakeholders in innovation creation

**Frequency:** 17

**Parent:** [[Stakeholder Engagement Methods]]

## Relationships

- targets [[smallholder farmers]]
- located_in [[Dolo Ado]]
- targets [[multi-stakeholder approaches]]
- uses [[teachers]]
- targets [[smallholder farmers]]
- located_in [[Dolo Ado]]
- targets [[multi-stakeholder approaches]]
- uses [[teachers]]

## Referenced By

- [[multifunctional landscapes]] uses this
- [[on-farm trials]] uses this
- [[International Livestock Research Institute]] uses this
- [[multifunctional landscapes]] uses this
- [[on-farm trials]] uses this
- [[International Livestock Research Institute]] uses this
