# capacity sharing

collaborative exchange of skills, knowledge, and resources between institutions

**Frequency:** 3

**Parent:** [[Capacity Building Approaches]]

## Relationships

- uses [[CapSha Marketplace]]
- uses [[CapSha Marketplace]]

## Referenced By

- [[localization]] uses this
- [[localization]] uses this
