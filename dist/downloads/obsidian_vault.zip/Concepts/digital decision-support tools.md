# digital decision-support tools

technology platforms that provide data-driven recommendations for agricultural management

**Frequency:** 1

**Parent:** [[Decision Support Systems]]


## Referenced By

- [[Rice Crop Manager]] produces this
- [[Rice Crop Manager]] produces this
