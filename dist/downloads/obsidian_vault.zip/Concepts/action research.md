# action research

research approach combining investigation with direct action for social change

**Frequency:** 1

**Parent:** [[Participatory Learning Methods]]

