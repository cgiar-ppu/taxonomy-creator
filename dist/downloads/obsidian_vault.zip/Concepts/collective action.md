# collective action

coordinated community efforts to address shared challenges

**Frequency:** 2

**Parent:** [[Governance Frameworks]]

## Relationships

- addresses [[Lantana camara]]
- located_in [[Lake Victoria]]
- addresses [[Lantana camara]]
- located_in [[Lake Victoria]]
