# emission factors

standardized coefficients used to estimate greenhouse gas emissions from activities

**Frequency:** 4

**Parent:** [[Greenhouse Gas Measurement and Reporting]]

## Relationships

- uses [[IPCC]]
- uses [[IPCC]]

## Referenced By

- [[bayesian inference]] produces this
- [[greenhouse gas inventory]] uses this
- [[bayesian inference]] produces this
- [[greenhouse gas inventory]] uses this
