# black soldier fly farming

insect-based agricultural production system for protein and waste management

**Frequency:** 1

**Parent:** [[Uncategorized]]

## Relationships

- targets [[smallholder farmers]]
- targets [[smallholder farmers]]
