# Genetic Gain and Performance Assessment

Measuring genetic progress and breeding performance

**Parent:** [[Phenotyping and Trait Evaluation]]

