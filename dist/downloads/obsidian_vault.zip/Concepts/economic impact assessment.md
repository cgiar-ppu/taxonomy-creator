# economic impact assessment

quantitative evaluation of economic benefits and costs of interventions

**Frequency:** 2

**Parent:** [[Experimental and Evaluation Methods]]

## Relationships

- uses [[economic surplus model]]
- uses [[economic surplus model]]

## Referenced By

- [[CGIAR]] produces this
- [[CGIAR]] produces this
