# social protection systems

government programs providing support to vulnerable populations during crises

**Frequency:** 1

**Parent:** [[Social Protection in Fragile Contexts]]

## Relationships

- uses [[climate risk data]]
- uses [[climate risk data]]
