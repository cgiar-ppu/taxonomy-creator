# conflict classification

systematic categorization of different types of violence and conflict

**Frequency:** 1

**Parent:** [[Climate-Conflict Nexus]]

## Relationships

- addresses [[humanitarian responses]]
- addresses [[humanitarian responses]]
