# seasonal rainfall forecasting

prediction of precipitation patterns over seasonal timescales for agricultural planning

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- uses [[AClimate]]
- uses [[AClimate]]
