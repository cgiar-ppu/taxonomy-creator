# hygiene oversight

systematic monitoring and enforcement of sanitation standards

**Frequency:** 1

**Parent:** [[Food Safety Monitoring and Management]]

## Relationships

- located_in [[Kenya]]
- located_in [[Kenya]]

## Referenced By

- [[meat inspectors]] uses this
- [[meat inspectors]] uses this
