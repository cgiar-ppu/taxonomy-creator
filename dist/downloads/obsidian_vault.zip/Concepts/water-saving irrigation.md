# water-saving irrigation

irrigation techniques that reduce water consumption while maintaining crop productivity

**Frequency:** 1

**Parent:** [[Water Productivity and Efficiency]]

## Relationships

- addresses [[climate change mitigation]]
- addresses [[climate change mitigation]]
