# better management practices

standardized guidelines for sustainable and productive farming operations

**Frequency:** 3

**Parent:** [[Smallholder and Community Farming]]

## Relationships

- targets [[GIFT]]
- located_in [[Nigeria]]
- targets [[GIFT]]
- located_in [[Nigeria]]
