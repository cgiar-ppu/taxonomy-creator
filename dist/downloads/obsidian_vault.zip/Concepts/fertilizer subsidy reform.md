# fertilizer subsidy reform

policy changes to agricultural input support programs

**Frequency:** 1

**Parent:** [[Miscellaneous Methods and Approaches]]

## Relationships

- addresses [[agricultural support repurposing]]
- addresses [[agricultural support repurposing]]
