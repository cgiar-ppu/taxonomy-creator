# economic surplus modeling

analytical approach to quantify economic welfare impacts and benefits of interventions

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- targets [[cassava]]
- targets [[cassava]]
