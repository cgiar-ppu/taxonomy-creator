# rapid cycle recurrent selection

accelerated breeding approach that reduces cycle time from three years to one year

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- uses [[rice]]
- uses [[rice]]
