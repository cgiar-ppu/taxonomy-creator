# digital soil sensing

portable field-based technology for rapid soil property assessment

**Frequency:** 1

**Parent:** [[Digital Tools and Decision Support]]

## Relationships

- located_in [[India]]
- located_in [[India]]
