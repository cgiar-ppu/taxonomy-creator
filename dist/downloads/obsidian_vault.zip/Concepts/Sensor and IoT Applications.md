# Sensor and IoT Applications

Sensor networks and IoT applications in agriculture

**Parent:** [[Precision Agriculture and Smart Farming]]

