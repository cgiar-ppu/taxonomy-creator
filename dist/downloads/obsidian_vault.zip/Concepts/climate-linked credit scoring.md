# climate-linked credit scoring

financial risk assessment integrating climate data with borrower profiles

**Frequency:** 1

**Parent:** [[Insurance and Risk Finance]]

## Relationships

- targets [[microfinance institutions]]
- located_in [[Guatemala]]
- targets [[microfinance institutions]]
- located_in [[Guatemala]]
