# cluster randomized control trial

experimental design where groups rather than individuals are randomly assigned to treatments

**Frequency:** 1

**Parent:** [[Uncategorized]]

## Relationships

- located_in [[Narayanganj block]]
- located_in [[Narayanganj block]]
