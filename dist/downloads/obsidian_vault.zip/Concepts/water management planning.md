# water management planning

strategic allocation and scheduling of water resources for agricultural production

**Frequency:** 3

**Parent:** [[Water Governance and Management]]

## Relationships

- uses [[irrigation demand forecasting]]
- uses [[irrigation demand forecasting]]
