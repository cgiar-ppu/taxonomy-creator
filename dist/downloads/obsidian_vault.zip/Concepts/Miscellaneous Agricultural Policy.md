# Miscellaneous Agricultural Policy

Other agricultural policy concepts

**Parent:** [[Agricultural Policy and Reform]]

