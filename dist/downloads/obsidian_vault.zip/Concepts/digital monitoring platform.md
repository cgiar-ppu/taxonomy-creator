# digital monitoring platform

technology-based system for tracking and verification of activities

**Frequency:** 3

**Parent:** [[Digital Platforms and Infrastructure]]

