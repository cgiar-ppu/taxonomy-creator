# zoonotic disease surveillance

monitoring and detection of diseases transmissible between animals and humans

**Frequency:** 6

**Parent:** [[Uncategorized]]

## Relationships

- uses [[one health approach]]
- addresses [[hantavirus]]
- part_of [[one health approach]]
- uses [[one health approach]]
- addresses [[hantavirus]]
- part_of [[one health approach]]

## Referenced By

- [[one health approach]] addresses this
- [[one health approach]] addresses this
