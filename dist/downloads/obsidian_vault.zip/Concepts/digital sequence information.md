# digital sequence information

genomic data used for genetic resource characterization and analysis

**Frequency:** 3

**Parent:** [[Responsible and Ethical Innovation]]

## Relationships

- uses [[community of practice]]
- uses [[plant breeding]]
- uses [[community of practice]]
- uses [[plant breeding]]
