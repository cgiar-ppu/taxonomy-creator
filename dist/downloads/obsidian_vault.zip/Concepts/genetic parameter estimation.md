# genetic parameter estimation

statistical methods to quantify heritable variation in traits

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- uses [[marker-assisted selection]]
- uses [[marker-assisted selection]]
