# post-mined land restoration

rehabilitation of degraded mining sites for productive agricultural use

**Frequency:** 1

**Parent:** [[Sustainable Land Management]]


## Referenced By

- [[oil palm]] addresses this
- [[oil palm]] addresses this
