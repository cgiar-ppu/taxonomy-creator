# distributive justice

fair allocation of resources ensuring equitable access to quantity, quality, and affordability

**Frequency:** 1

**Parent:** [[Justice and Equity Frameworks]]


## Referenced By

- [[water justice]] uses this
- [[water justice]] uses this
