# experimental auctions

controlled market experiments to determine economic preferences

**Frequency:** 1

**Parent:** [[Mixed Methods and Qualitative Approaches]]

## Relationships

- uses [[willingness to pay assessment]]
- uses [[willingness to pay assessment]]
