# geographical indications

certification system linking product quality and characteristics to specific geographic origins

**Frequency:** 1

**Parent:** [[Miscellaneous Methods and Approaches]]

## Relationships

- addresses [[olive]]
- addresses [[olive]]
