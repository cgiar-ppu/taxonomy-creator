# Computer Vision and Image Processing

Computer vision and image-based AI applications

**Parent:** [[Artificial Intelligence and Machine Learning]]

