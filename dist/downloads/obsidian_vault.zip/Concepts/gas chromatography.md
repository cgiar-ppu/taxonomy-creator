# gas chromatography

analytical technique for separating and measuring greenhouse gases

**Frequency:** 2

**Parent:** [[Uncategorized]]


## Referenced By

- [[greenhouse gas measurement]] uses this
- [[greenhouse gas measurement]] uses this
