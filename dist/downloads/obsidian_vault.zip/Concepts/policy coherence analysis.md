# policy coherence analysis

systematic assessment of alignment and consistency across multiple policies

**Frequency:** 1

**Parent:** [[Integrated and Adaptive Management]]

## Relationships

- uses [[five-step process]]
- uses [[five-step process]]
