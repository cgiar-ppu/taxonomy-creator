# South-South Cooperation and Localization

South-south collaboration, technology transfer, localization, and knowledge exchange across countries and regions

**Parent:** [[Other / Cross-cutting]]

