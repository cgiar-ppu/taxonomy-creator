# hydrological monitoring

systematic measurement and tracking of water levels and flow in water bodies

**Frequency:** 1

**Parent:** [[Remote Sensing and Digital Monitoring]]

## Relationships

- uses [[computer vision]]
- uses [[computer vision]]
