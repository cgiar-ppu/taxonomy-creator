# irrigation demand management

strategies to optimize water use efficiency in irrigation systems

**Frequency:** 1

**Parent:** [[Irrigation and Water Infrastructure]]

## Relationships

- uses [[Soil Moisture Sensors]]
- uses [[Soil Moisture Sensors]]
