# land restoration

practices to rehabilitate degraded landscapes and ecosystems

**Frequency:** 3

**Parent:** [[Sustainable Land Management]]

## Relationships

- located_in [[Wajir County]]
- uses [[oil palm]]
- located_in [[Wajir County]]
- uses [[oil palm]]
