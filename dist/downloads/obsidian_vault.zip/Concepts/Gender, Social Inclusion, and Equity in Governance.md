# Gender, Social Inclusion, and Equity in Governance

Gender-responsive and socially inclusive governance frameworks

**Parent:** [[Policy, Governance, and Institutional Systems]]

