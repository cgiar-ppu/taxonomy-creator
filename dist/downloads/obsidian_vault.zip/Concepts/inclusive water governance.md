# inclusive water governance

water management frameworks that ensure equitable participation and benefit-sharing

**Frequency:** 2

**Parent:** [[Miscellaneous Methods and Approaches]]

## Relationships

- located_in [[Indus Basin]]
- located_in [[Indus Basin]]
