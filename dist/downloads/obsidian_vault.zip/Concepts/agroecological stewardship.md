# agroecological stewardship

practices that promote environmental sustainability and ecological health in agricultural systems

**Frequency:** 4

**Parent:** [[Transformative Change]]

## Relationships

- targets [[teachers]]
- targets [[teachers]]

## Referenced By

- [[multipurpose trees]] part_of this
- [[multipurpose trees]] part_of this
