# decision-support tools

digital platforms and frameworks that assist in agricultural decision-making

**Aliases:** decision support tool

**Frequency:** 4

**Parent:** [[Decision Support Systems]]

## Relationships

- uses [[regenerative agriculture]]
- uses [[regenerative agriculture]]
