# informal food vendors

unregistered small-scale food sellers operating in urban environments

**Frequency:** 1

**Parent:** [[Food Environment Assessment]]

## Relationships

- located_in [[Dhaka]]
- located_in [[Quezon City]]
- located_in [[Dhaka]]
- located_in [[Quezon City]]

## Referenced By

- [[Quezon City]] targets this
- [[Quezon City]] targets this
