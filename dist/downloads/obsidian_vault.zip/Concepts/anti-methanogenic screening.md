# anti-methanogenic screening

laboratory testing to identify compounds that reduce methane production

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- uses [[metabolomic analysis]]
- uses [[metabolomic analysis]]
