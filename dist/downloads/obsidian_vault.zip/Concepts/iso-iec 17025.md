# iso/iec 17025

international standard for testing and calibration laboratory competence

**Frequency:** 1

**Parent:** [[Miscellaneous Methods and Approaches]]

## Relationships

- targets [[laboratory quality]]
- targets [[laboratory quality]]

## Referenced By

- [[IRRI]] uses this
- [[IRRI]] uses this
