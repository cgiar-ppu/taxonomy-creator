# gender-sensitive interventions

development interventions designed to address gender-specific needs and constraints

**Frequency:** 3

**Parent:** [[Gender-Responsive Programming]]

