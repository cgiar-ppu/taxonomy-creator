# variety demonstration

field-based showcasing of crop varieties to promote adoption

**Frequency:** 1

**Parent:** [[Participatory Breeding and Variety Selection]]

## Relationships

- targets [[smallholder farmers]]
- targets [[smallholder farmers]]
