# loop-mediated isothermal amplification

DNA amplification technique that operates at constant temperature for rapid detection

**Frequency:** 1

**Parent:** [[Uncategorized]]

