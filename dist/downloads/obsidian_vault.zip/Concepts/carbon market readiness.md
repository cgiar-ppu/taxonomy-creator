# carbon market readiness

capacity building to enable participation in carbon trading mechanisms

**Frequency:** 1

**Parent:** [[Climate Finance]]

## Relationships

- targets [[Turkana County]]
- targets [[Turkana County]]
