# Biodiversity and Agrobiodiversity

Biodiversity conservation, agrobiodiversity monitoring, ecosystem services, and biodiversity-positive practices

**Parent:** [[Climate Change, Environment, and Natural Resources]]

