# tricot approach

triadic comparison method for on-farm testing where farmers rank three technologies

**Frequency:** 3

**Parent:** [[Citizen Science and Crowdsourcing]]

## Relationships

- uses [[ClimMob platform]]
- uses [[ClimMob platform]]

## Referenced By

- [[citizen science]] part_of this
- [[participatory research]] uses this
- [[citizen science]] part_of this
- [[participatory research]] uses this
