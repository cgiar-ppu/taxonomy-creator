# econometric analysis

**Parent:** [[Mixed Methods and Qualitative Approaches]]

