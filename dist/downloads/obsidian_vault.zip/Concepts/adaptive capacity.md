# adaptive capacity

ability of systems to adjust to climate change and reduce vulnerability

**Frequency:** 3

**Parent:** [[Resilience Frameworks]]

