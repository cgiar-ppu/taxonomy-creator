# adaptive social protection

social safety nets that adjust to climate and economic shocks

**Frequency:** 1

**Parent:** [[Social Protection in Fragile Contexts]]


## Referenced By

- [[Honduras]] uses this
- [[Honduras]] uses this
