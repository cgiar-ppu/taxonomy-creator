# choice experiment

research method using hypothetical scenarios to elicit preferences

**Frequency:** 1

**Parent:** [[Mixed Methods and Qualitative Approaches]]

## Relationships

- addresses [[food safety]]
- addresses [[food safety]]
