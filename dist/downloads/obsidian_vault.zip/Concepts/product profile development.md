# product profile development

defining target traits and characteristics for specific market segments

**Frequency:** 3

**Parent:** [[Innovation Assessment and Bundling]]

## Relationships

- addresses [[market-responsive breeding]]
- addresses [[market-responsive breeding]]
