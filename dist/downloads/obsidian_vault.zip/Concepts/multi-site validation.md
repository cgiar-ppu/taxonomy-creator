# multi-site validation

testing technologies across multiple locations to assess performance and adaptability

**Frequency:** 1

**Parent:** [[Field and On-Farm Trials]]

