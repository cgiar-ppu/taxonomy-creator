# Molecular Markers and Fingerprinting

Molecular marker development and application

**Parent:** [[Genomics and Molecular Tools]]

