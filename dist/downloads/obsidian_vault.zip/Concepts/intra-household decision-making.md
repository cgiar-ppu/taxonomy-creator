# intra-household decision-making

**Parent:** [[Intra-household and Community Dynamics]]

