# heat stress analysis

quantitative assessment of temperature impacts on crops, livestock, and human populations

**Frequency:** 4

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- targets [[smallholder farmer]]
- targets [[smallholder farmer]]
