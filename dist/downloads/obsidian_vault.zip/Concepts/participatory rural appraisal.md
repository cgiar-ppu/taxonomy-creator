# participatory rural appraisal

community-based research method using local knowledge and participation

**Frequency:** 1

**Parent:** [[Participatory Learning Methods]]

## Relationships

- addresses [[gender dynamics]]
- addresses [[gender dynamics]]
