# school feeding programs

institutional programs providing nutritious meals to school children

**Aliases:** school feeding program

**Frequency:** 6

**Parent:** [[Miscellaneous Methods and Approaches]]

## Relationships

- uses [[chickens]]
- located_in [[Yemen]]
- addresses [[food security]]
- uses [[chickens]]
- located_in [[Yemen]]
- addresses [[food security]]
