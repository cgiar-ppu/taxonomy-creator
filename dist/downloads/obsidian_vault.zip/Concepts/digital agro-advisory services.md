# digital agro-advisory services

technology-enabled platforms delivering agricultural guidance and recommendations to farmers

**Frequency:** 4

**Parent:** [[Digital Advisory and Extension]]


## Referenced By

- [[climate information services]] produces this
- [[climate-smart agriculture]] uses this
- [[climate information services]] produces this
- [[climate-smart agriculture]] uses this
