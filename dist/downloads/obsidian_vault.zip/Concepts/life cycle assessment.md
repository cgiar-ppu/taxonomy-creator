# life cycle assessment

evaluation of environmental impacts throughout a product's entire life cycle

**Frequency:** 1

**Parent:** [[Experimental and Evaluation Methods]]

## Relationships

- uses [[carbon footprint assessment]]
- uses [[carbon footprint assessment]]
