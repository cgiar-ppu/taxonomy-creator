# postharvest loss reduction

strategies to minimize food waste after harvest

**Frequency:** 2

**Parent:** [[Supply Chain and Post-Harvest]]

## Relationships

- uses [[tomato]]
- uses [[tomato]]

## Referenced By

- [[Southeast Asia]] addresses this
- [[reusable plastic crates]] addresses this
- [[Southeast Asia]] addresses this
- [[reusable plastic crates]] addresses this
