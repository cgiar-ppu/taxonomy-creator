# Nutrition Security and Dietary Quality

Nutrition-sensitive agriculture, dietary diversity, biofortification, and malnutrition reduction

**Parent:** [[Food Systems, Nutrition, and Food Security]]

