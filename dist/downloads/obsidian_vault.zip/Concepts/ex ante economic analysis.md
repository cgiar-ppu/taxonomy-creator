# ex ante economic analysis

forward-looking assessment of investment returns before implementation

**Frequency:** 2

**Parent:** [[Experimental and Evaluation Methods]]

## Relationships

- located_in [[Sub-Saharan Africa]]
- located_in [[Sub-Saharan Africa]]
