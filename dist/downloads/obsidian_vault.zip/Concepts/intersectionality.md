# intersectionality

analysis considering multiple overlapping social identities and systems of oppression

**Frequency:** 2

**Parent:** [[Social Inclusion and Intersectionality]]


## Referenced By

- [[women's empowerment]] related_to this
- [[women's empowerment]] related_to this
