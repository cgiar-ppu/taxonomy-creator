# breeding pipeline

structured sequence of breeding activities and selection stages

**Frequency:** 8

**Parent:** [[Crop Genetic Improvement]]


## Referenced By

- [[multi-environment testing]] part_of this
- [[multi-environment testing]] part_of this
