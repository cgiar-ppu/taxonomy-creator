# circular economy

economic model emphasizing resource reuse and waste reduction

**Frequency:** 7

**Parent:** [[Circular Economy Principles]]

## Relationships

- collaborates_with [[SENA]]
- uses [[regenerative agriculture]]
- targets [[rice]]
- addresses [[food systems resilience]]
- addresses [[waste hierarchy]]
- collaborates_with [[SENA]]
- uses [[regenerative agriculture]]
- targets [[rice]]
- addresses [[food systems resilience]]
- addresses [[waste hierarchy]]

## Referenced By

- [[India]] uses this
- [[aerobic composting]] produces this
- [[biogas production]] addresses this
- [[India]] uses this
- [[aerobic composting]] produces this
- [[biogas production]] addresses this
