# Aquaculture and Aquatic Food Systems

Aquaculture development, integrated rice-fish systems, small-scale fisheries, and aquatic food production

**Parent:** [[Sustainable Farming Systems and Practices]]

