# participatory cultivar selection

farmer involvement in variety evaluation and selection before commercial release

**Frequency:** 2

**Parent:** [[Participatory Breeding and Variety Selection]]


## Referenced By

- [[demand-driven breeding]] uses this
- [[demand-driven breeding]] uses this
