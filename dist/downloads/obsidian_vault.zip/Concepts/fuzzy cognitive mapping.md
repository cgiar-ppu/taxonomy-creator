# fuzzy cognitive mapping

participatory method to model stakeholder perceptions of system relationships

**Frequency:** 1

**Parent:** [[Uncategorized]]

## Relationships

- located_in [[China]]
- located_in [[China]]
