# digital public infrastructure

shared digital platforms and protocols that enable scalable service delivery

**Frequency:** 1

**Parent:** [[Digital Platforms and Infrastructure]]

## Relationships

- located_in [[India]]
- located_in [[India]]
