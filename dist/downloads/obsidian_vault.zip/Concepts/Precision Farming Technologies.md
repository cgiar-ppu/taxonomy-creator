# Precision Farming Technologies

Core precision agriculture and smart farming tools

**Parent:** [[Precision Agriculture and Smart Farming]]

