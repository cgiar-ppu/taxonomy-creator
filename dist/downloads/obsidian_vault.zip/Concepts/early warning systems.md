# early warning systems

monitoring and forecasting systems to predict and prepare for emergencies

**Aliases:** early warning system

**Frequency:** 35

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- addresses [[climate vulnerability]]
- targets [[fall armyworm]]
- targets [[Striga]]
- located_in [[Rwanda]]
- targets [[soybean rust]]
- located_in [[Eastern Africa]]
- located_in [[Southern Africa]]
- addresses [[drought management]]
- uses [[community-based climate observation]]
- addresses [[disaster risk management]]
- uses [[PakDMS]]
- uses [[satellite-based monitoring]]
- located_in [[West Africa]]
- uses [[climate information services]]
- part_of [[climate information services]]
- addresses [[climate-conflict nexus]]
- uses [[satellite remote sensing]]
- addresses [[climate vulnerability]]
- targets [[fall armyworm]]
- targets [[Striga]]
- located_in [[Rwanda]]
- targets [[soybean rust]]
- located_in [[Eastern Africa]]
- located_in [[Southern Africa]]
- addresses [[drought management]]
- uses [[community-based climate observation]]
- addresses [[disaster risk management]]
- uses [[PakDMS]]
- uses [[satellite-based monitoring]]
- located_in [[West Africa]]
- uses [[climate information services]]
- part_of [[climate information services]]
- addresses [[climate-conflict nexus]]
- uses [[satellite remote sensing]]

## Referenced By

- [[machine learning modeling]] uses this
- [[humanitarian practitioners]] uses this
- [[climate information services]] uses this
- [[anticipatory action]] uses this
- [[machine learning modeling]] uses this
- [[humanitarian practitioners]] uses this
- [[climate information services]] uses this
- [[anticipatory action]] uses this
