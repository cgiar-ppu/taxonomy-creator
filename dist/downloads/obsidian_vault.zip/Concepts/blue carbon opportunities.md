# blue carbon opportunities

carbon sequestration potential in marine and coastal ecosystems

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]

