# demonstration plot training

hands-on learning approach using field demonstrations to transfer technology

**Frequency:** 1

**Parent:** [[Training and Capacity Development]]


## Referenced By

- [[smallholder farmers]] uses this
- [[smallholder farmers]] uses this
