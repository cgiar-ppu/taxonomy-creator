# greenhouse gas emission measurement

techniques to quantify agricultural emissions for climate action

**Frequency:** 3

**Parent:** [[Greenhouse Gas Measurement and Reporting]]


## Referenced By

- [[alternate wetting and drying]] addresses this
- [[alternate wetting and drying]] addresses this
