# Drone and UAV Applications

Unmanned aerial vehicle applications in agriculture

**Parent:** [[Remote Sensing and Earth Observation]]

