# digital transformation

integration of digital technologies to reshape agricultural and food systems

**Frequency:** 8

**Parent:** [[Digital Platforms and Infrastructure]]

## Relationships

- located_in [[Colombia]]
- produces [[AGX platform]]
- produces [[traceability]]
- part_of [[CGIAR]]
- located_in [[Colombia]]
- produces [[AGX platform]]
- produces [[traceability]]
- part_of [[CGIAR]]

## Referenced By

- [[generative artificial intelligence]] part_of this
- [[human-centered design]] targets this
- [[generative artificial intelligence]] part_of this
- [[human-centered design]] targets this
