# Dietary Assessment and Quality

Methods and tools for assessing dietary diversity and quality

**Parent:** [[Nutrition Security and Dietary Quality]]

