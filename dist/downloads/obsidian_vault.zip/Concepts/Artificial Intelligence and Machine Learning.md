# Artificial Intelligence and Machine Learning

AI and machine learning applications in agriculture

**Parent:** [[Digital Technologies for Agriculture]]

