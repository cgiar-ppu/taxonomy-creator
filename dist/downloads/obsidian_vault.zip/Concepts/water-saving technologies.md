# water-saving technologies

innovations and practices that reduce agricultural water consumption

**Frequency:** 1

**Parent:** [[Water Productivity and Efficiency]]

## Relationships

- targets [[smallholder farmer]]
- targets [[smallholder farmer]]
