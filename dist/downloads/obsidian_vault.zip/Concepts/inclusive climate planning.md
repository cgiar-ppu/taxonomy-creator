# inclusive climate planning

participatory planning processes that ensure diverse stakeholder representation in climate initiatives

**Frequency:** 1

**Parent:** [[Gender-Responsive Policy and Governance]]

