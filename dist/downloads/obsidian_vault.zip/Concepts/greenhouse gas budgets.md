# greenhouse gas budgets

comprehensive accounting of anthropogenic and natural sources and sinks of greenhouse gases

**Frequency:** 1

**Parent:** [[Greenhouse Gas Measurement and Reporting]]


## Referenced By

- [[South Asia]] produces this
- [[South Asia]] produces this
