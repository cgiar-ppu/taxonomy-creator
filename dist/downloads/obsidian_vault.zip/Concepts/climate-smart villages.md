# climate-smart villages

community-based research sites for testing and demonstrating climate adaptation technologies

**Frequency:** 3

**Parent:** [[Scaling and Innovation Miscellaneous]]

## Relationships

- produces [[climate-smart agriculture]]
- located_in [[Senegal]]
- uses [[participatory research]]
- produces [[climate-smart agriculture]]
- located_in [[Senegal]]
- uses [[participatory research]]
