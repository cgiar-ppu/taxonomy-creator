# vegetative propagation

plant reproduction using vegetative parts rather than seeds

**Frequency:** 3

**Parent:** [[Crop Genetic Improvement]]

## Relationships

- part_of [[cassava]]
- uses [[carob]]
- part_of [[cassava]]
- uses [[carob]]
