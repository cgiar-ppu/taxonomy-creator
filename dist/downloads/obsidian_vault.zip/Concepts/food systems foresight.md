# food systems foresight

strategic planning methodology for anticipating future food system changes

**Frequency:** 1

**Parent:** [[Food Systems Transformation]]

## Relationships

- located_in [[Tunisia]]
- located_in [[Tunisia]]
