# crop-livestock integration

farming approach combining crop and animal production for mutual benefits

**Frequency:** 1

**Parent:** [[Uncategorized]]

## Relationships

- targets [[smallholder farmers]]
- targets [[smallholder farmers]]
