# focus group

**Parent:** [[Qualitative and Social Research Techniques]]

