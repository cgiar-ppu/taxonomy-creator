# trader-centered seed systems

seed distribution networks that place traders at the center of connecting producers with farmers

**Frequency:** 1

**Parent:** [[Market-Oriented Seed Systems]]

## Relationships

- produces [[beans]]
- produces [[beans]]
