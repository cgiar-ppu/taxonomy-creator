# market-responsive breeding

crop breeding aligned with specific market demands and consumer preferences

**Frequency:** 6

**Parent:** [[Market-Oriented Seed Systems]]

## Relationships

- targets [[banana]]
- targets [[banana]]

## Referenced By

- [[breeding program assessment]] uses this
- [[product profile development]] addresses this
- [[breeding program assessment]] uses this
- [[product profile development]] addresses this
