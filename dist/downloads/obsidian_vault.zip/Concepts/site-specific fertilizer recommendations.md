# site-specific fertilizer recommendations

customized nutrient management based on local soil and climate conditions

**Aliases:** site-specific fertilizer recommendation

**Frequency:** 15

**Parent:** [[Climate and Agro-Advisory Services]]

## Relationships

- part_of [[LAFA/HaFAS]]
- uses [[evidence-based decision support]]
- part_of [[LAFA/HaFAS]]
- uses [[evidence-based decision support]]

## Referenced By

- [[Rwanda]] targets this
- [[RiceAdvice Lite]] produces this
- [[AgWise]] produces this
- [[NextGen Decision Support Tool]] produces this
- [[RiceAdvice]] produces this
- [[Rwanda]] targets this
- [[RiceAdvice Lite]] produces this
- [[AgWise]] produces this
- [[NextGen Decision Support Tool]] produces this
- [[RiceAdvice]] produces this
