# digital extension platforms

technology-enabled systems for delivering agricultural advisory services to farmers

**Frequency:** 5

**Parent:** [[Digital Advisory and Extension]]

## Relationships

- targets [[smallholder farmers]]
- targets [[smallholder farmers]]

## Referenced By

- [[IRRI]] produces this
- [[rice]] part_of this
- [[IRRI]] produces this
- [[rice]] part_of this
