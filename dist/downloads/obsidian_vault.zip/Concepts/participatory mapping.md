# participatory mapping

collaborative approach involving farmers in adaptation planning and field-level solutions

**Frequency:** 7

**Parent:** [[Participatory Learning Methods]]


## Referenced By

- [[CS-MAP]] uses this
- [[locally led climate adaptation]] uses this
- [[pastoralists]] uses this
- [[CS-MAP]] uses this
- [[locally led climate adaptation]] uses this
- [[pastoralists]] uses this
