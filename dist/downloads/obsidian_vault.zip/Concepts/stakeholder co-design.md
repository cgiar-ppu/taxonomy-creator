# stakeholder co-design

collaborative design process involving all relevant parties in solution development

**Frequency:** 2

**Parent:** [[Stakeholder Engagement Methods]]

## Relationships

- produces [[theory of change]]
- produces [[theory of change]]
