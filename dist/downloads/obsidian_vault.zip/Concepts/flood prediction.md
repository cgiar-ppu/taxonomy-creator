# flood prediction

forecasting approach to anticipate inundation extent and timing for agricultural risk management

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]


## Referenced By

- [[machine learning model]] addresses this
- [[machine learning model]] addresses this
