# Germplasm and Genetic Resources

Conservation, characterization, and utilization of genetic diversity including gene banks and germplasm collections

**Parent:** [[Crop Improvement and Genetics]]

