# location-specific recommendations

tailored agricultural advice based on local environmental and crop conditions

**Frequency:** 2

**Parent:** [[Precision and Digital Crop Management]]


## Referenced By

- [[RiceAdvice Lite]] produces this
- [[RiceAdvice Lite]] produces this
- [[RiceAdvice Lite]] produces this
- [[RiceAdvice Lite]] produces this
