# home-grown school feeding

programs linking local food production with school nutrition

**Frequency:** 4

**Parent:** [[Miscellaneous Methods and Approaches]]

## Relationships

- uses [[gender-responsive programming]]
- uses [[biofortified crops]]
- uses [[gender-responsive programming]]
- uses [[biofortified crops]]
