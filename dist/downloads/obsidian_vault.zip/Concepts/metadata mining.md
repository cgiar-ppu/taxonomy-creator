# metadata mining

automated extraction and organization of dataset descriptions for improved data integration

**Frequency:** 1

**Parent:** [[Digital Platforms and Infrastructure]]

