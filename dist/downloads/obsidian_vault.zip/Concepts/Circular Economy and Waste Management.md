# Circular Economy and Waste Management

Circular economy principles, waste-to-value technologies, resource recovery, and bioeconomy approaches

**Parent:** [[Other / Cross-cutting]]

