# metadata standardization

establishing consistent data description and classification systems

**Frequency:** 1

**Parent:** [[Digital Platforms and Infrastructure]]

