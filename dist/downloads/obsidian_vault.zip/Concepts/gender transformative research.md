# gender transformative research

research approaches that challenge and transform underlying causes of gender inequalities

**Frequency:** 7

**Parent:** [[Gender Transformative Approaches]]

## Relationships

- addresses [[gender inequality]]
- addresses [[gender inequalities]]
- targets [[plant breeders]]
- addresses [[gender inequality]]
- addresses [[gender inequalities]]
- targets [[plant breeders]]
