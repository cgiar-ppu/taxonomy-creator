# participatory research

research approach involving stakeholders as active participants in knowledge generation

**Frequency:** 32

**Parent:** [[Participatory Learning Methods]]

## Relationships

- uses [[knowledge exchange]]
- targets [[women farmers]]
- uses [[tricot approach]]
- uses [[multistakeholder networks]]
- uses [[knowledge exchange]]
- targets [[women farmers]]
- uses [[tricot approach]]
- uses [[multistakeholder networks]]

## Referenced By

- [[climate services]] uses this
- [[smallholder farmers]] targets this
- [[agroecosystem living labs]] uses this
- [[ICRISAT]] uses this
- [[territorial innovation networks]] uses this
- [[FEAST]] uses this
- [[scaling for impact]] uses this
- [[climate-smart villages]] uses this
- [[climate services]] uses this
- [[smallholder farmers]] targets this
- [[agroecosystem living labs]] uses this
- [[ICRISAT]] uses this
- [[territorial innovation networks]] uses this
- [[FEAST]] uses this
- [[scaling for impact]] uses this
- [[climate-smart villages]] uses this
