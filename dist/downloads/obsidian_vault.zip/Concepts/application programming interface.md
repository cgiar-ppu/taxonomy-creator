# application programming interface

software interface that allows different systems to communicate and exchange data

**Frequency:** 1

**Parent:** [[Digital Platforms and Infrastructure]]


## Referenced By

- [[Climate+]] uses this
- [[Climate+]] uses this
