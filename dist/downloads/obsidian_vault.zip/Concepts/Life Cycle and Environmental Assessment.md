# Life Cycle and Environmental Assessment

Methods for assessing environmental impacts and sustainability

**Parent:** [[Economic and Systems Modeling]]

