# localization

shifting leadership and decision-making to local actors in development interventions

**Frequency:** 1

**Parent:** [[South-South and Knowledge Exchange]]

## Relationships

- uses [[capacity sharing]]
- uses [[capacity sharing]]
