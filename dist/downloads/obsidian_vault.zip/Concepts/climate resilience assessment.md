# climate resilience assessment

systematic evaluation of systems' ability to withstand climate impacts

**Frequency:** 4

**Parent:** [[Resilience Frameworks]]


## Referenced By

- [[National Climate Policy]] addresses this
- [[National Climate Policy]] addresses this
