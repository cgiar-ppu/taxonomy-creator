# interactive voice response

technology that allows interaction with computer systems through voice commands and responses

**Frequency:** 1

**Parent:** [[Digital Advisory and Extension]]

## Relationships

- targets [[smallholder farmers]]
- targets [[smallholder farmers]]
