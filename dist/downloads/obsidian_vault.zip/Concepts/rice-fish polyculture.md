# rice-fish polyculture

integrated farming system combining rice cultivation with fish production

**Frequency:** 1

**Parent:** [[Uncategorized]]

## Relationships

- located_in [[Myanmar]]
- located_in [[Myanmar]]
