# agroforestry systems

integrated land-use combining trees with crops or livestock

**Frequency:** 1

**Parent:** [[Agroforestry and Silvopastoral Systems]]

## Relationships

- located_in [[Pucallpa]]
- located_in [[Pucallpa]]
