# unmanned aerial vehicles

drone technology for agricultural applications including spraying and monitoring

**Frequency:** 1

**Parent:** [[Remote Sensing and Earth Observation]]

## Relationships

- uses [[herbicide application]]
- uses [[herbicide application]]
