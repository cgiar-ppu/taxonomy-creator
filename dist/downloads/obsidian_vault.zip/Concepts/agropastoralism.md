# agropastoralism

integrated farming system combining crop production and livestock keeping

**Frequency:** 1

**Parent:** [[Landscape and Ecosystem Approaches]]

## Relationships

- addresses [[climate adaptation]]
- addresses [[climate adaptation]]
