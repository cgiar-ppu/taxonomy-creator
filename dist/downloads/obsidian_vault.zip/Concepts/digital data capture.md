# digital data capture

electronic collection and recording of information using digital platforms and tools

**Frequency:** 1

**Parent:** [[Digital Platforms and Infrastructure]]


## Referenced By

- [[International Livestock Research Institute]] uses this
- [[International Livestock Research Institute]] uses this
