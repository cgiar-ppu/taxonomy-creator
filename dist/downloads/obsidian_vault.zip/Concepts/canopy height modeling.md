# canopy height modeling

estimation of crop structural parameters using remote sensing or other technologies

**Frequency:** 1

**Parent:** [[Remote Sensing and Digital Monitoring]]

