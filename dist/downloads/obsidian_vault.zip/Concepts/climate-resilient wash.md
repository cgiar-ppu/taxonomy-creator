# climate-resilient wash

water, sanitation and hygiene systems designed to withstand climate impacts

**Frequency:** 1

**Parent:** [[Climate Resilience Building]]

## Relationships

- uses [[groundwater integration]]
- uses [[groundwater integration]]
