# Evidence Generation and Policy Uptake

Evidence-based policy, impact evaluation, policy dialogue, science-policy interface, and policy advocacy

**Parent:** [[Policy, Governance, and Institutional Systems]]

