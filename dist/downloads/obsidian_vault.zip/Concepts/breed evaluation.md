# breed evaluation

systematic assessment of animal genetic resources for performance traits

**Frequency:** 1

**Parent:** [[Uncategorized]]

## Relationships

- targets [[chickens]]
- targets [[chickens]]
