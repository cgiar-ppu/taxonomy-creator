# community-based seed production

decentralized seed production and marketing managed by local communities

**Frequency:** 4

**Parent:** [[Seed Systems Development]]

## Relationships

- targets [[chickpea]]
- produces [[biofortified crops]]
- targets [[chickpea]]
- produces [[biofortified crops]]
