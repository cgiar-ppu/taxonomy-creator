# market systems development

intervention strategy that addresses systemic barriers in market functioning

**Frequency:** 2

**Parent:** [[Market Analysis and Assessment]]

## Relationships

- targets [[pigs]]
- addresses [[smallholder farmers]]
- targets [[pigs]]
- addresses [[smallholder farmers]]
