# farmer-led irrigation development

smallholder-driven investment and management of irrigation systems

**Frequency:** 2

**Parent:** [[Irrigation and Water Infrastructure]]

## Relationships

- located_in [[Kenya]]
- located_in [[Kenya]]
