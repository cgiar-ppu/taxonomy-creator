# regulatory oversight

systematic monitoring and enforcement of standards and regulations

**Frequency:** 1

**Parent:** [[Miscellaneous Methods and Approaches]]


## Referenced By

- [[meat inspectors]] uses this
- [[meat inspectors]] uses this
