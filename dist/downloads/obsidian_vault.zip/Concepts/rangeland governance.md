# rangeland governance

institutional arrangements for managing communal grazing lands and resources

**Frequency:** 2

**Parent:** [[Miscellaneous Methods and Approaches]]

## Relationships

- part_of [[pastoralist systems]]
- part_of [[pastoralist systems]]
