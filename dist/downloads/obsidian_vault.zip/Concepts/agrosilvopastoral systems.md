# agrosilvopastoral systems

integrated land-use systems combining trees, crops, and livestock for multiple benefits

**Frequency:** 1

**Parent:** [[Agroforestry and Silvopastoral Systems]]

## Relationships

- uses [[olive]]
- uses [[olive]]

## Referenced By

- [[Tunisia]] uses this
- [[Tunisia]] uses this
