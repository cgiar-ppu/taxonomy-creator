# refugee policy impact

political and social effects of policies governing refugee populations

**Frequency:** 2

**Parent:** [[Displacement and Migration]]

## Relationships

- located_in [[Sub-Saharan Africa]]
- located_in [[Sub-Saharan Africa]]
