# model farms

demonstration sites showcasing integrated agricultural technologies and practices

**Frequency:** 2

**Parent:** [[Participatory and Community Learning Methods]]

## Relationships

- uses [[herd health management]]
- uses [[herd health management]]
