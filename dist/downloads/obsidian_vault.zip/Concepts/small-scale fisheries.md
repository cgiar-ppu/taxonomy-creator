# small-scale fisheries

artisanal fishing operations typically characterized by low capital investment and local community involvement

**Frequency:** 3

**Parent:** [[Fisheries and Aquatic Food Systems]]

## Relationships

- located_in [[Western Indian Ocean]]
- located_in [[Western Indian Ocean]]

## Referenced By

- [[data harmonization]] addresses this
- [[data harmonization]] addresses this
