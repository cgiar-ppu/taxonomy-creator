# monitoring, reporting, and verification

systems for tracking and validating climate action progress

**Frequency:** 3

**Parent:** [[MRV Frameworks]]

## Relationships

- part_of [[climate adaptation]]
- part_of [[climate adaptation]]
