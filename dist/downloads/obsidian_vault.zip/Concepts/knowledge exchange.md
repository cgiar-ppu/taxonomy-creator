# knowledge exchange

systematic sharing and transfer of information and expertise between stakeholders

**Frequency:** 4

**Parent:** [[South-South and Knowledge Exchange]]

## Relationships

- collaborates_with [[Australia]]
- collaborates_with [[Australia]]

## Referenced By

- [[participatory research]] uses this
- [[participatory research]] uses this
