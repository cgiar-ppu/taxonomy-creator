# women's land ownership

legal and social recognition of women's rights to own and control land resources

**Frequency:** 1

**Parent:** [[Women's Empowerment]]

