# drone-based monitoring

use of unmanned aerial vehicles for data collection and measurement

**Frequency:** 2

**Parent:** [[Remote Sensing and Earth Observation]]

## Relationships

- uses [[atmospheric dispersion modeling]]
- located_in [[Kenya]]
- uses [[atmospheric dispersion modeling]]
- located_in [[Kenya]]
