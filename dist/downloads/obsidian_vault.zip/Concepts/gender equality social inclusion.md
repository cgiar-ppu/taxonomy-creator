# gender equality social inclusion

ensuring equitable participation and benefits for all groups

**Frequency:** 3

**Parent:** [[Gender Transformative Approaches]]


## Referenced By

- [[innovation platforms]] targets this
- [[innovation platforms]] targets this
