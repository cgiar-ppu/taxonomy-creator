# no-tillage farming

agricultural practice that avoids mechanical soil disturbance to preserve soil structure and moisture

**Frequency:** 1

**Parent:** [[Soil Health and Management]]

## Relationships

- produces [[soil moisture monitoring]]
- produces [[soil moisture monitoring]]
