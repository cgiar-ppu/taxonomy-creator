# food safety monitoring

systematic surveillance of contaminants and hazards in food systems

**Frequency:** 2

**Parent:** [[Miscellaneous Methods and Approaches]]


## Referenced By

- [[value chain upgrading]] addresses this
- [[value chain upgrading]] addresses this
