# agribusiness acceleration

structured support to help agricultural enterprises scale and access markets

**Frequency:** 3

**Parent:** [[Blended Finance and Investment]]

## Relationships

- uses [[last-mile distribution]]
- uses [[last-mile distribution]]
