# seed priming

pre-sowing treatment to enhance seed germination and seedling vigor

**Frequency:** 1

**Parent:** [[Seed Systems Development]]

## Relationships

- addresses [[disease development]]
- addresses [[disease development]]
