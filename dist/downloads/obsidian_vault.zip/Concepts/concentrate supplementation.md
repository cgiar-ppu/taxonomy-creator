# concentrate supplementation

feeding strategy providing concentrated nutrients to livestock

**Frequency:** 1

**Parent:** [[Uncategorized]]

## Relationships

- produces [[average daily gain]]
- reduces [[methane emissions]]
- produces [[average daily gain]]
- reduces [[methane emissions]]

## Referenced By

- [[pastoralists]] uses this
- [[pastoralists]] uses this
