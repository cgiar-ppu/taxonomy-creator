# aflatoxin contamination

presence of toxic compounds produced by fungi that cause liver cancer and stunting

**Frequency:** 1

**Parent:** [[Contaminant and Residue Management]]

## Relationships

- located_in [[Kenya]]
- located_in [[Kenya]]

## Referenced By

- [[maize]] related_to this
- [[maize]] related_to this
