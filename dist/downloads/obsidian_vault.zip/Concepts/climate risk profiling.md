# climate risk profiling

systematic assessment of climate hazards and vulnerabilities for agricultural planning

**Frequency:** 4

**Parent:** [[Specialized Analytical Techniques]]


## Referenced By

- [[bundled climate-smart solutions]] uses this
- [[Africa Agriculture Adaptation Atlas]] produces this
- [[bundled climate-smart solutions]] uses this
- [[Africa Agriculture Adaptation Atlas]] produces this
