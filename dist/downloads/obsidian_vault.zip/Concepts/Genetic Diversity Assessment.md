# genetic diversity assessment

evaluation of genetic variation within crop populations

**Frequency:** 2

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- uses [[sweet potato]]
- uses [[sweet potato]]
