# intra-household information sharing

flow of knowledge and data between members within farming households

**Frequency:** 1

**Parent:** [[Social Inclusion and Intersectionality]]

## Relationships

- related_to [[gender roles]]
- related_to [[gender roles]]
