# digital advisory platforms

technology-based systems for delivering agricultural and climate advisories

**Frequency:** 5

**Parent:** [[Digital Advisory and Extension]]


## Referenced By

- [[EDACaP-V2]] produces this
- [[AgDataHub]] part_of this
- [[EDACaP-V2]] produces this
- [[AgDataHub]] part_of this
