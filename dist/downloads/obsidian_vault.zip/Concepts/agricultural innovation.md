# agricultural innovation

development and adoption of new technologies and practices in farming systems

**Frequency:** 1

**Parent:** [[Uncategorized]]


## Referenced By

- [[science of scaling]] addresses this
- [[CGIAR]] produces this
- [[science of scaling]] addresses this
- [[CGIAR]] produces this
