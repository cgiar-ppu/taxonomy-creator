# flood tolerance

ability of crops to survive and produce under flooding conditions

**Frequency:** 1

**Parent:** [[Crop Genetic Improvement]]


## Referenced By

- [[FOFIFA 198]] produces this
- [[FOFIFA 198]] produces this
