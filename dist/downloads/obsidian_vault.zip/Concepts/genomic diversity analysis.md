# genomic diversity analysis

use of DNA sequencing data to understand genetic variation patterns in crops

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- targets [[yam]]
- targets [[yam]]

## Referenced By

- [[MSc student]] uses this
- [[MSc student]] uses this
