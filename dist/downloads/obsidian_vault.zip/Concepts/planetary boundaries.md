# planetary boundaries

safe operating limits for Earth system processes that regulate planet stability

**Frequency:** 1

**Parent:** [[Transformative Change]]


## Referenced By

- [[food systems transformation]] addresses this
- [[food systems transformation]] addresses this
