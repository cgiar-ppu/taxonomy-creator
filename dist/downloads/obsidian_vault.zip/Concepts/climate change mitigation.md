# climate change mitigation

actions to reduce greenhouse gas emissions and limit global warming

**Frequency:** 12

**Parent:** [[Low-Carbon and Zero-Carbon Agriculture]]


## Referenced By

- [[biological inputs]] addresses this
- [[eco-compensation]] addresses this
- [[biochar application]] addresses this
- [[water-saving irrigation]] addresses this
- [[drought tolerant varieties]] addresses this
- [[food systems transformation]] addresses this
- [[biological inputs]] addresses this
- [[eco-compensation]] addresses this
- [[biochar application]] addresses this
- [[water-saving irrigation]] addresses this
- [[drought tolerant varieties]] addresses this
- [[food systems transformation]] addresses this
