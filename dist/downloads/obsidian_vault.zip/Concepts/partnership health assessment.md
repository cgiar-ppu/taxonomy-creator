# partnership health assessment

evaluation of collaboration effectiveness among institutional partners

**Frequency:** 1

**Parent:** [[Miscellaneous Methods and Approaches]]

