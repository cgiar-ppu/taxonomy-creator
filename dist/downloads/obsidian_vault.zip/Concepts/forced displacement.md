# forced displacement

involuntary movement of people due to conflict, persecution, or environmental factors

**Frequency:** 4

**Parent:** [[Displacement and Migration]]

## Relationships

- produces [[mental health impacts]]
- produces [[mental health impacts]]

## Referenced By

- [[climate change]] produces this
- [[climate change]] produces this
