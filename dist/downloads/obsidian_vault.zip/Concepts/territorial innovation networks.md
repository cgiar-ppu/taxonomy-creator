# territorial innovation networks

collaborative networks linking research, extension and farmers across geographic territories

**Frequency:** 2

**Parent:** [[Communities of Practice and Networks]]

## Relationships

- located_in [[Guatemala]]
- uses [[participatory research]]
- located_in [[Guatemala]]
- uses [[participatory research]]
