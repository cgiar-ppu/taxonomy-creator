# Digital Innovation and Data Science

Covers digital technologies, data-driven tools, remote sensing, and artificial intelligence applied to agriculture

