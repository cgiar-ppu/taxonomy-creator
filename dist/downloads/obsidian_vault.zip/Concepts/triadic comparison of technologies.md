# triadic comparison of technologies

participatory evaluation method where farmers compare three technologies simultaneously

**Frequency:** 2

**Parent:** [[Citizen Science and Crowdsourcing]]

## Relationships

- uses [[participatory variety selection]]
- uses [[participatory variety selection]]
