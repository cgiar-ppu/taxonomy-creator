# multinomial ordered logit regression

statistical method for analyzing ordered categorical outcomes with multiple response levels

**Frequency:** 1

**Parent:** [[Uncategorized]]


## Referenced By

- [[trait preference ranking]] uses this
- [[trait preference ranking]] uses this
