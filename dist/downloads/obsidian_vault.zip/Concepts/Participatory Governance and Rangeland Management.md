# Participatory Governance and Rangeland Management

Participatory governance and community-based natural resource management

**Parent:** [[Participatory Research and Co-Design]]

