# theory of change

comprehensive description of how and why desired change is expected to happen

**Frequency:** 4

**Parent:** [[Integrated and Adaptive Management]]

## Relationships

- part_of [[multifunctional landscapes]]
- part_of [[multifunctional landscapes]]

## Referenced By

- [[stakeholder co-design]] produces this
- [[stakeholder co-design]] produces this
