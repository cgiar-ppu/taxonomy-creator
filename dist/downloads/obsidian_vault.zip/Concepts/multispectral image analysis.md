# multispectral image analysis

automated analysis using multiple wavelengths of light for species identification

**Frequency:** 1

**Parent:** [[Remote Sensing and Digital Monitoring]]

## Relationships

- uses [[machine learning classification]]
- uses [[machine learning classification]]
