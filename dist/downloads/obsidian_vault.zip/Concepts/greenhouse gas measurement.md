# greenhouse gas measurement

quantification of emissions from agricultural systems using standardized protocols and equipment

**Frequency:** 12

**Parent:** [[Greenhouse Gas Measurement and Reporting]]

## Relationships

- uses [[gas chromatography]]
- uses [[LI-COR Trace Gas Analyzers]]
- located_in [[Thailand]]
- uses [[gas chromatography]]
- uses [[LI-COR Trace Gas Analyzers]]
- located_in [[Thailand]]

## Referenced By

- [[circular economy principles]] addresses this
- [[nitrogen isotope analysis]] part_of this
- [[circular economy solutions]] addresses this
- [[circular economy principles]] addresses this
- [[nitrogen isotope analysis]] part_of this
- [[circular economy solutions]] addresses this
