# serosurvey

epidemiological study measuring antibodies in blood samples

**Frequency:** 1

**Parent:** [[Uncategorized]]

## Relationships

- targets [[Coxiella burnetii]]
- targets [[Coxiella burnetii]]
