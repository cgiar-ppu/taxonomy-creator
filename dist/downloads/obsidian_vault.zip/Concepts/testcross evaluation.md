# testcross evaluation

crossing experimental lines with standard testers to evaluate performance

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]


## Referenced By

- [[combining ability analysis]] uses this
- [[combining ability analysis]] uses this
