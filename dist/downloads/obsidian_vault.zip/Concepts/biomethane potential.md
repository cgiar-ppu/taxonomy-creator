# biomethane potential

measure of maximum methane yield from organic feedstock under anaerobic conditions

**Frequency:** 1

**Parent:** [[Biogas and Bioenergy]]


## Referenced By

- [[anaerobic digestion]] produces this
- [[anaerobic digestion]] produces this
