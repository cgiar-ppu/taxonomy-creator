# participatory governance

inclusive decision-making processes involving multiple stakeholders

**Frequency:** 10

**Parent:** [[Governance Frameworks]]

## Relationships

- uses [[multifunctional landscapes]]
- located_in [[Sajnen Forest]]
- uses [[multifunctional landscapes]]
- located_in [[Sajnen Forest]]

## Referenced By

- [[ecosystem restoration]] uses this
- [[Municipality of Pachacamac]] uses this
- [[ecosystem restoration]] uses this
- [[Municipality of Pachacamac]] uses this
