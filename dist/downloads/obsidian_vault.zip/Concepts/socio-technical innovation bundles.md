# socio-technical innovation bundles

integrated packages combining technological innovations with social interventions

**Frequency:** 4

**Parent:** [[Innovation Bundling and Packages]]

## Relationships

- addresses [[climate risks]]
- part_of [[whole-farm innovation bundles]]
- addresses [[climate risks]]
- part_of [[whole-farm innovation bundles]]
