# forage evaluation

assessment of feed crops for biomass production and nutritional quality

**Frequency:** 2

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- uses [[Urochloa brizantha]]
- located_in [[Bahir Dar University]]
- uses [[Urochloa brizantha]]
- located_in [[Bahir Dar University]]
