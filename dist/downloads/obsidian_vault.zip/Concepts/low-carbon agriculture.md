# low-carbon agriculture

agricultural systems designed to minimize greenhouse gas emissions while maintaining productivity

**Frequency:** 2

**Parent:** [[Planetary and Environmental Sustainability]]


## Referenced By

- [[solar irrigation]] addresses this
- [[solar irrigation]] addresses this
