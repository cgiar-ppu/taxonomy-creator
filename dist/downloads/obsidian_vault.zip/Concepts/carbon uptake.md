# carbon uptake

process by which ecosystems absorb atmospheric carbon dioxide through photosynthesis

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]


## Referenced By

- [[eddy covariance]] produces this
- [[eddy covariance]] produces this
