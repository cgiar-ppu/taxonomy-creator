# conjunctive water use

combined use of different water sources to optimize water resource management

**Frequency:** 1

**Parent:** [[Irrigation and Water Infrastructure]]


## Referenced By

- [[banana]] uses this
- [[Pakistan]] uses this
- [[banana]] uses this
- [[Pakistan]] uses this
