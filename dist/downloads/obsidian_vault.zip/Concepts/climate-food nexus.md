# climate-food nexus

interconnected relationship between climate change and food systems

**Frequency:** 1

**Parent:** [[Uncategorized]]

## Relationships

- located_in [[Pacific Islands]]
- located_in [[Pacific Islands]]
