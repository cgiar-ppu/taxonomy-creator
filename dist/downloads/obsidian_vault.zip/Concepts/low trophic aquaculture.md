# low trophic aquaculture

fish farming systems using species that feed low in the food chain

**Frequency:** 1

**Parent:** [[Uncategorized]]

## Relationships

- uses [[bioinformatics analysis]]
- uses [[bioinformatics analysis]]
