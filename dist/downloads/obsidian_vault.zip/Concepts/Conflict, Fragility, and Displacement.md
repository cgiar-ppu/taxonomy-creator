# Conflict, Fragility, and Displacement

Conflict-sensitive programming, fragile settings, forced displacement, climate-conflict nexus, and peacebuilding

**Parent:** [[Gender, Social Inclusion, and Human Wellbeing]]

