# rice straw transformation

converting rice straw waste into valuable products for circular economy applications

**Frequency:** 1

**Parent:** [[Post-Harvest Technology and Storage]]

## Relationships

- located_in [[Mekong River Delta]]
- located_in [[Mekong River Delta]]
