# vision-to-action approach

participatory process to translate shared community visions into concrete, measurable actions

**Frequency:** 2

**Parent:** [[Communication and Outreach]]

## Relationships

- produces [[participatory monitoring and evaluation]]
- produces [[participatory monitoring and evaluation]]

## Referenced By

- [[CIAT]] uses this
- [[CIAT]] uses this
