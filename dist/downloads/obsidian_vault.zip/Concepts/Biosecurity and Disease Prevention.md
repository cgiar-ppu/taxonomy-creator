# Biosecurity and Disease Prevention

Biosecurity practices and disease prevention frameworks

**Parent:** [[One Health and Zoonotic Disease]]

