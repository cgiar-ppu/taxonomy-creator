# zero deforestation compliance

monitoring and verification systems to ensure supply chains do not contribute to forest loss

**Frequency:** 2

**Parent:** [[Sustainable Land Management]]


## Referenced By

- [[VISIPRAST]] uses this
- [[VISIPRAST]] uses this
