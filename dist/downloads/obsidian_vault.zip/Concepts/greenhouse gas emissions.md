# greenhouse gas emissions

release of gases that contribute to climate change from agricultural activities

**Frequency:** 21

**Parent:** [[Greenhouse Gas Measurement and Monitoring]]

## Relationships

- produces [[emission intensity]]
- produces [[emission intensity]]

## Referenced By

- [[IRRI]] addresses this
- [[mechanized direct seeding]] addresses this
- [[biogas digester technology]] addresses this
- [[rice]] produces this
- [[nitrogen management]] addresses this
- [[climate-smart agriculture]] addresses this
- [[International Livestock Research Institute]] uses this
- [[Calliandra calothyrsus]] produces this
- [[biogas digester performance]] produces this
- [[sheep]] produces this
- [[enteric fermentation]] produces this
- [[biogas production]] addresses this
- [[livestock value chains]] produces this
- [[alternate wetting and drying]] addresses this
- [[integrated soil fertility management]] addresses this
- [[nitrogen use efficiency]] addresses this
- [[IRRI]] addresses this
- [[mechanized direct seeding]] addresses this
- [[biogas digester technology]] addresses this
- [[rice]] produces this
- [[nitrogen management]] addresses this
- [[climate-smart agriculture]] addresses this
- [[International Livestock Research Institute]] uses this
- [[Calliandra calothyrsus]] produces this
- [[biogas digester performance]] produces this
- [[sheep]] produces this
- [[enteric fermentation]] produces this
- [[biogas production]] addresses this
- [[livestock value chains]] produces this
- [[alternate wetting and drying]] addresses this
- [[integrated soil fertility management]] addresses this
- [[nitrogen use efficiency]] addresses this
