# Adaptation Planning and Implementation

Strategies and frameworks for planning and implementing climate adaptation

**Parent:** [[Climate Adaptation and Resilience]]

