# participatory validation

research approach involving stakeholders in confirming and refining findings

**Frequency:** 1

**Parent:** [[Uncategorized]]

## Relationships

- located_in [[India]]
- located_in [[India]]
