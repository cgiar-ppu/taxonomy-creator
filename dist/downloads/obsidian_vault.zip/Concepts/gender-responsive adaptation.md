# gender-responsive adaptation

climate adaptation strategies that address differential impacts and needs by gender

**Frequency:** 1

**Parent:** [[Gender-Responsive Programming]]

