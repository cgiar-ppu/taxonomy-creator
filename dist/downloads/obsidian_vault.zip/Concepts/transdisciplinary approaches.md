# transdisciplinary approaches

research and intervention methods that integrate multiple disciplines and stakeholder perspectives

**Frequency:** 1

**Parent:** [[Systems and Transdisciplinary Research]]

