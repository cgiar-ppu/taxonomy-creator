# Digital Platforms and Infrastructure

Digital platforms, infrastructure, and data systems

**Parent:** [[Digital Technologies for Agriculture]]

