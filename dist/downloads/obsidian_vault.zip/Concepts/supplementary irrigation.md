# supplementary irrigation

targeted water application during critical crop growth stages in rainfed systems

**Frequency:** 1

**Parent:** [[Irrigation and Water Infrastructure]]

## Relationships

- addresses [[yield variability]]
- addresses [[yield variability]]
