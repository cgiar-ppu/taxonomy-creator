# digital tracking system

technology-based monitoring and data collection system for agricultural interventions

**Frequency:** 3

**Parent:** [[Digital Platforms and Infrastructure]]

## Relationships

- targets [[development agents]]
- targets [[development agents]]
