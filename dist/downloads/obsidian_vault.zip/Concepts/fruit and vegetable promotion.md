# fruit and vegetable promotion

interventions designed to increase consumption of fruits and vegetables

**Frequency:** 6

**Parent:** [[Dietary Behavior and Interventions]]

## Relationships

- located_in [[Fiji]]
- located_in [[Fiji]]

## Referenced By

- [[women of reproductive age]] targets this
- [[FRESH]] targets this
- [[women of reproductive age]] targets this
- [[FRESH]] targets this
