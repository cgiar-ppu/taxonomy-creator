# drought stress management

strategies to mitigate water deficit impacts on crop production

**Frequency:** 2

**Parent:** [[Uncategorized]]

## Relationships

- targets [[banana]]
- targets [[banana]]
