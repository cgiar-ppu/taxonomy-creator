# Participatory Breeding and Variety Selection

Farmer-led and participatory approaches to crop improvement

**Parent:** [[Participatory Research and Co-Design]]

