# process-based simulation

modeling approach using mechanistic understanding of biological and physical processes

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]

