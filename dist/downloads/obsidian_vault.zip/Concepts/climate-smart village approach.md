# climate-smart village approach

integrated community-level framework for implementing climate-smart agriculture

**Frequency:** 4

**Parent:** [[Scaling and Innovation Miscellaneous]]

## Relationships

- located_in [[West Africa]]
- uses [[INSAH/CILSS]]
- located_in [[West Africa]]
- uses [[INSAH/CILSS]]

## Referenced By

- [[AICCRA]] uses this
- [[AICCRA]] uses this
