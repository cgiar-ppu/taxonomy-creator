# participatory framework

structured approach involving multiple stakeholders in decision-making processes

**Frequency:** 1

**Parent:** [[Participatory Learning Methods]]

## Relationships

- addresses [[climate-smart agriculture]]
- addresses [[climate-smart agriculture]]
