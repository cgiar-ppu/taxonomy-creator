# nutritional enhancement

improving the nutritional content of foods through ingredient modification or fortification

**Frequency:** 5

**Parent:** [[Nutrition-Sensitive Approaches]]

## Relationships

- produces [[gluten-free products]]
- produces [[gluten-free products]]

## Referenced By

- [[alternative flour blending]] produces this
- [[chia]] produces this
- [[alternative flour blending]] produces this
- [[chia]] produces this
