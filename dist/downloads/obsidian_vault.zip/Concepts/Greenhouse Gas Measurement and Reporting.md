# Greenhouse Gas Measurement and Reporting

Methods for measuring, reporting, and verifying greenhouse gas emissions

**Parent:** [[Monitoring, Evaluation, and Learning]]

