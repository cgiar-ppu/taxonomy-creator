# transfer learning

machine learning approach applying knowledge from one domain to another

**Frequency:** 1

**Parent:** [[Artificial Intelligence and Machine Learning]]

## Relationships

- uses [[genomic prediction]]
- uses [[genomic prediction]]
