# population genomics

study of genetic variation and evolution within and between populations

**Frequency:** 2

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- uses [[quantitative trait loci mapping]]
- uses [[quantitative trait loci mapping]]
