# emission intensity per weight gain

ratio of greenhouse gas emissions to livestock weight gain

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]

