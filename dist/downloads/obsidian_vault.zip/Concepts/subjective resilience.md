# subjective resilience

household-perceived capacity to anticipate, withstand, recover from, and adapt to hazards

**Frequency:** 2

**Parent:** [[Resilience Frameworks]]

## Relationships

- related_to [[climate hazard mapping]]
- related_to [[climate hazard mapping]]
