# floating agriculture

cultivation on floating beds in waterlogged areas

**Frequency:** 2

**Parent:** [[Urban Farming Systems]]

## Relationships

- located_in [[Bangladesh]]
- located_in [[Bangladesh]]
