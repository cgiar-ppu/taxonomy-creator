# chemical control trials

field experiments testing effectiveness of chemical treatments for pest and disease management

**Frequency:** 1

**Parent:** [[Uncategorized]]

## Relationships

- located_in [[Hubei]]
- located_in [[Yunnan]]
- located_in [[Beijing]]
- targets [[farmers]]
- located_in [[Hubei]]
- located_in [[Yunnan]]
- located_in [[Beijing]]
- targets [[farmers]]
