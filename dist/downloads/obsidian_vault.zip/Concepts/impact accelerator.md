# impact accelerator

coordinated system design to enhance adoption of agricultural innovations

**Frequency:** 1

**Parent:** [[Blended Finance and Investment]]

