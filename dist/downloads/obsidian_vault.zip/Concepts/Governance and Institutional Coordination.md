# Governance and Institutional Coordination

Multi-stakeholder platforms, institutional coordination, polycentric and participatory governance

**Parent:** [[Policy, Governance, and Institutional Systems]]

