# Food Access and Social Protection

Interventions to improve food access and social protection for food security

**Parent:** [[Food Environment and Consumer Behavior]]

