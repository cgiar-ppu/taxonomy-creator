# forest restoration

activities to restore degraded forest ecosystems

**Frequency:** 2

**Parent:** [[Sustainable Land Management]]


## Referenced By

- [[MyFarmTrees]] uses this
- [[MyFarmTrees]] uses this
