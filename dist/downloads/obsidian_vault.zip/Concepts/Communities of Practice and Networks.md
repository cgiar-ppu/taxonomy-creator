# Communities of Practice and Networks

Learning networks, communities of practice, and innovation platforms

**Parent:** [[Capacity Building and Learning]]

