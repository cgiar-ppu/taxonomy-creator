# climate-induced displacement

forced migration resulting from climate change impacts and extreme weather events

**Frequency:** 4

**Parent:** [[Displacement and Migration]]


## Referenced By

- [[climate security]] addresses this
- [[climate security]] addresses this
