# nutrition-sensitive markets

market systems that prioritize and reward nutritional quality in agricultural products

**Frequency:** 1

**Parent:** [[Food Market Systems]]

