# water-efficient agriculture

farming practices that optimize water use while maintaining productivity

**Frequency:** 2

**Parent:** [[Water Productivity and Efficiency]]


## Referenced By

- [[IWMI]] produces this
- [[drip irrigation]] part_of this
- [[IWMI]] produces this
- [[drip irrigation]] part_of this
