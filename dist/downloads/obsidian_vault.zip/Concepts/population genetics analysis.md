# population genetics analysis

study of genetic variation and structure within pathogen or crop populations

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- uses [[Phytophthora infestans]]
- uses [[Phytophthora infestans]]
