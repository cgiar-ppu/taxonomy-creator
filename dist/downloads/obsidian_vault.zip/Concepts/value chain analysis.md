# value chain analysis

examination of production to consumption linkages and market dynamics

**Frequency:** 20

**Parent:** [[Statistical and Quantitative Methods]]

## Relationships

- targets [[groundnut]]
- targets [[wholesaler]]
- targets [[neglected and underutilized species]]
- targets [[goat]]
- uses [[rice]]
- targets [[agricultural transformation]]
- uses [[climate vulnerability assessment]]
- targets [[Honduras]]
- targets [[fish farmers]]
- targets [[groundnut]]
- targets [[wholesaler]]
- targets [[neglected and underutilized species]]
- targets [[goat]]
- uses [[rice]]
- targets [[agricultural transformation]]
- uses [[climate vulnerability assessment]]
- targets [[Honduras]]
- targets [[fish farmers]]
