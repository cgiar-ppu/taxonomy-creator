# Partnership Models

Frameworks for public-private collaboration

**Parent:** [[Public-Private Partnerships and Investment]]

