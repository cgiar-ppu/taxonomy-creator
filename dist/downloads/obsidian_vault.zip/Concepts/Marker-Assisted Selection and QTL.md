# Marker-Assisted Selection and QTL

Molecular marker technologies for trait selection

**Parent:** [[Genomics and Molecular Tools]]

