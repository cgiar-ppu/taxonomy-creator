# climate negotiations

international diplomatic processes to address climate change

**Frequency:** 1

**Parent:** [[Miscellaneous Methods and Approaches]]

## Relationships

- addresses [[food security]]
- addresses [[food security]]
