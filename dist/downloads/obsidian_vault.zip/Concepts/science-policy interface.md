# science-policy interface

mechanisms connecting scientific research with policy development and implementation

**Frequency:** 1

**Parent:** [[Integrated and Adaptive Management]]


## Referenced By

- [[water-energy-food-environment nexus]] uses this
- [[water-energy-food-environment nexus]] uses this
