# solar-powered aquaculture

fish production systems using renewable solar energy

**Frequency:** 1

**Parent:** [[Uncategorized]]

## Relationships

- targets [[smallholder farmers]]
- targets [[smallholder farmers]]
