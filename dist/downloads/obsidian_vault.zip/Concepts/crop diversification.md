# crop diversification

agricultural strategy of growing multiple crop species to reduce risk and improve sustainability

**Frequency:** 21

**Parent:** [[Sustainable Intensification and Diversification]]

## Relationships

- located_in [[Bangladesh]]
- targets [[maize]]
- addresses [[food security]]
- located_in [[Bangladesh]]
- uses [[pearl millet]]
- uses [[sorghum]]
- located_in [[Odisha]]
- located_in [[Bangladesh]]
- targets [[maize]]
- addresses [[food security]]
- located_in [[Bangladesh]]
- uses [[pearl millet]]
- uses [[sorghum]]
- located_in [[Odisha]]

## Referenced By

- [[climate-smart agriculture]] uses this
- [[agroecology]] uses this
- [[pigeonpea]] part_of this
- [[climate-smart agriculture]] uses this
- [[agroecology]] uses this
- [[pigeonpea]] part_of this
