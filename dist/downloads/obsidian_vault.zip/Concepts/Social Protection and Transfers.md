# Social Protection and Transfers

Social protection programs and cash transfer mechanisms

**Parent:** [[Finance, Insurance, and Risk Management]]

