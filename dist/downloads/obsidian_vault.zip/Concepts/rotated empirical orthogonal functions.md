# rotated empirical orthogonal functions

statistical technique for analyzing spatial patterns in climate data

**Frequency:** 1

**Parent:** [[Uncategorized]]


## Referenced By

- [[spatiotemporal climate analysis]] uses this
- [[spatiotemporal climate analysis]] uses this
