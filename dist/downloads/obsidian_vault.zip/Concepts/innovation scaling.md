# innovation scaling

process of expanding successful agricultural innovations to broader adoption

**Frequency:** 6

**Parent:** [[Scaling Frameworks and Strategies]]

## Relationships

- targets [[CGIAR]]
- uses [[demand signaling]]
- targets [[CGIAR]]
- uses [[demand signaling]]

## Referenced By

- [[multistakeholder networks]] uses this
- [[CGIAR]] uses this
- [[multistakeholder networks]] uses this
- [[CGIAR]] uses this
