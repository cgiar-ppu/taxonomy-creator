# small-scale mechanization

use of small machinery like power tillers and mowers in agricultural production

**Frequency:** 3

**Parent:** [[Mechanization Technologies]]

## Relationships

- uses [[power tillers]]
- located_in [[Tunisia]]
- uses [[power tillers]]
- located_in [[Tunisia]]
