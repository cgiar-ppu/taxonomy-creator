# forage adoption

uptake of improved grass varieties by livestock farmers

**Frequency:** 1

**Parent:** [[Technology Adoption and Diffusion]]

