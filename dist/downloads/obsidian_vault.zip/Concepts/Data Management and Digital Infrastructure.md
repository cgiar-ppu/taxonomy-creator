# Data Management and Digital Infrastructure

Data standardization, interoperability, digital public infrastructure, data platforms, and knowledge management systems

**Parent:** [[Digital Innovation and Data Science]]

