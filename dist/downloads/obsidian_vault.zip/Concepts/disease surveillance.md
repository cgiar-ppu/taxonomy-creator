# disease surveillance

systematic monitoring and detection of plant diseases across geographic areas

**Frequency:** 4

**Parent:** [[Zoonotic Disease Surveillance and Management]]

