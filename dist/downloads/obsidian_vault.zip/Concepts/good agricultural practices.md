# good agricultural practices

science-backed farming techniques including timely planting, optimal fertilizer rates, and improved varieties

**Frequency:** 9

**Parent:** [[Quality and Food Safety Standards]]

## Relationships

- targets [[maize]]
- targets [[maize]]

## Referenced By

- [[yield gap closure]] uses this
- [[extension workers]] uses this
- [[yield gap closure]] uses this
- [[extension workers]] uses this
