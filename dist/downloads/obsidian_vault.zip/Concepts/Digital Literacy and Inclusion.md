# Digital Literacy and Inclusion

Digital literacy, inclusiveness, and access to digital tools

**Parent:** [[Digital Literacy and Data Systems for Extension]]

