# mechanized direct-seeded rice

climate-smart rice cultivation technology using machines for precision sowing instead of transplanting

**Aliases:** mechanized direct seeded rice

**Frequency:** 4

**Parent:** [[Mechanization Technologies]]

## Relationships

- is_a [[climate-smart agriculture]]
- is_a [[climate-smart agriculture]]

## Referenced By

- [[precision sowing]] uses this
- [[precision sowing]] uses this
