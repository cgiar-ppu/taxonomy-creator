# co-production

collaborative development process involving multiple stakeholders

**Frequency:** 2

**Parent:** [[Stakeholder Engagement Methods]]

## Relationships

- produces [[gender-responsive approaches]]
- located_in [[Senegal]]
- produces [[gender-responsive approaches]]
- located_in [[Senegal]]
