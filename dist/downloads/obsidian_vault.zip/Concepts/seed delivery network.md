# seed delivery network

coordinated system of organizations that multiply and distribute improved crop varieties to farmers

**Frequency:** 1

**Parent:** [[Market-Oriented Seed Systems]]

## Relationships

- targets [[smallholder farmers]]
- targets [[smallholder farmers]]
