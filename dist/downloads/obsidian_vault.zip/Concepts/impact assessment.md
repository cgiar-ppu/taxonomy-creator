# impact assessment

systematic evaluation of intervention effects on outcomes

**Frequency:** 1

**Parent:** [[Experimental and Evaluation Methods]]

## Relationships

- located_in [[Zambia]]
- located_in [[Zambia]]
