# Gender Research Methods

Specific methods for gender analysis and gender-responsive research

**Parent:** [[Gender and Social Inclusion Methods]]

