# climate policy coordination

systematic coordination of climate action and policy implementation across government levels

**Frequency:** 1

**Parent:** [[Miscellaneous Methods and Approaches]]

