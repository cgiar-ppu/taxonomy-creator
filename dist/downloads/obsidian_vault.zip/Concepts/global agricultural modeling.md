# global agricultural modeling

mathematical simulation of agricultural systems at global scale to analyze market and production dynamics

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]

