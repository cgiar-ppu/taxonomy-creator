# zero-carbon villages

rural communities designed to achieve net-zero carbon emissions

**Frequency:** 1

**Parent:** [[Planetary and Environmental Sustainability]]

## Relationships

- addresses [[carbon neutrality]]
- located_in [[Yangtze River Delta]]
- addresses [[carbon neutrality]]
- located_in [[Yangtze River Delta]]
