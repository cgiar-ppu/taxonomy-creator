# polymorphism information content

measure of genetic marker informativeness based on allele frequencies

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- part_of [[single nucleotide polymorphisms]]
- part_of [[single nucleotide polymorphisms]]
