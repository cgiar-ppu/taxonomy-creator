# innovation platforms

multi-stakeholder forums for collaborative problem-solving and knowledge sharing

**Aliases:** innovation platform

**Frequency:** 5

**Parent:** [[Communities of Practice and Networks]]

## Relationships

- uses [[participatory approach]]
- targets [[gender equality social inclusion]]
- uses [[participatory approach]]
- targets [[gender equality social inclusion]]
