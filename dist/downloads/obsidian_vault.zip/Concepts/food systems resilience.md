# food systems resilience

capacity of food systems to withstand and recover from shocks while maintaining functionality

**Frequency:** 4

**Parent:** [[Food Systems Transformation]]


## Referenced By

- [[circular economy]] addresses this
- [[circular economy]] addresses this
