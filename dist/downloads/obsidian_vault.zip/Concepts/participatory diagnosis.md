# participatory diagnosis

collaborative assessment of needs and priorities involving stakeholders

**Frequency:** 5

**Parent:** [[Participatory Learning Methods]]

## Relationships

- uses [[capacity strengthening]]
- uses [[multi-stakeholder platforms]]
- uses [[capacity strengthening]]
- uses [[multi-stakeholder platforms]]
