# gender norms measurement

quantitative tools for assessing and tracking changes in gender-related social norms

**Frequency:** 1

**Parent:** [[Gender Dynamics and Analysis]]


## Referenced By

- [[CGIAR Gender Equality Initiative]] produces this
- [[CGIAR Gender Equality Initiative]] produces this
