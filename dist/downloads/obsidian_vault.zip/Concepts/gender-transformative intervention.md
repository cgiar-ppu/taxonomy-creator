# gender-transformative intervention

development strategies that address structural gender inequalities and power dynamics

**Frequency:** 3

**Parent:** [[Gender Transformative Approaches]]

## Relationships

- produces [[empowerment]]
- produces [[empowerment]]

## Referenced By

- [[smallholder farmer]] targets this
- [[smallholder farmer]] targets this
