# germplasm utilization

use of genetic resources from gene banks or research collections for crop improvement

**Frequency:** 28

**Parent:** [[Crop Genetic Improvement]]


## Referenced By

- [[variety registration]] uses this
- [[Alliance of Bioversity and CIAT]] uses this
- [[variety registration]] uses this
- [[Alliance of Bioversity and CIAT]] uses this
