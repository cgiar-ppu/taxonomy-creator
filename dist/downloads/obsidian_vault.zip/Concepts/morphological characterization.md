# morphological characterization

systematic description of physical traits in crop varieties or landraces

**Frequency:** 4

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- uses [[Phureja]]
- uses [[potato]]
- uses [[Phureja]]
- uses [[potato]]
