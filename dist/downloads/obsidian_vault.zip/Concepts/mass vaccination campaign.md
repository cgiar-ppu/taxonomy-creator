# mass vaccination campaign

large-scale immunization program targeting animal or human populations

**Frequency:** 1

**Parent:** [[Uncategorized]]

## Relationships

- targets [[rabies]]
- targets [[rabies]]
