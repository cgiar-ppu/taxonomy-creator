# area-based yield insurance

insurance coverage based on regional average yields rather than individual farm losses

**Frequency:** 1

**Parent:** [[Insurance and Risk Finance]]

## Relationships

- uses [[PRISM]]
- uses [[PRISM]]
