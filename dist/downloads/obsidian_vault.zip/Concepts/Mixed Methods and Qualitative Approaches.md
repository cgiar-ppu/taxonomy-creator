# Mixed Methods and Qualitative Approaches

Mixed methods and qualitative research approaches

**Parent:** [[Research Methods and Evidence Generation]]

