# circular bioeconomy

economic model using biological resources in circular value chains

**Frequency:** 11

**Parent:** [[Circular Economy Principles]]

## Relationships

- located_in [[Ghana]]
- located_in [[India]]
- addresses [[climate change]]
- addresses [[livestock waste recovery]]
- targets [[climate resilience]]
- produces [[resource recovery]]
- addresses [[agroecological transition]]
- located_in [[Addis Ababa]]
- located_in [[Ghana]]
- located_in [[India]]
- addresses [[climate change]]
- addresses [[livestock waste recovery]]
- targets [[climate resilience]]
- produces [[resource recovery]]
- addresses [[agroecological transition]]
- located_in [[Addis Ababa]]

## Referenced By

- [[anaerobic digestion]] addresses this
- [[anaerobic digestion]] addresses this
