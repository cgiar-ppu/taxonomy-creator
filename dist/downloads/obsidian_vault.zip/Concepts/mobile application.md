# mobile application

software platform designed for mobile devices to deliver services or information

**Frequency:** 1

**Parent:** [[Digital Advisory and Extension]]


## Referenced By

- [[mechanization services]] uses this
- [[mechanization services]] uses this
