# heterotic group development

classification of breeding lines based on combining ability for hybrid development

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- uses [[multi-environment trial evaluation]]
- uses [[multi-environment trial evaluation]]

## Referenced By

- [[ADCIN]] uses this
- [[ADCIN]] uses this
