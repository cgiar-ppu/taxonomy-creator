# mechanized agriculture services

provision of machinery and equipment for agricultural operations

**Frequency:** 2

**Parent:** [[Mechanization Service Models]]

## Relationships

- targets [[smallholder farmers]]
- targets [[smallholder farmers]]

## Referenced By

- [[Center for Mechanized Agriculture]] uses this
- [[Center for Mechanized Agriculture]] uses this
