# zero tillage production

agricultural practice of growing crops without mechanically disturbing the soil

**Frequency:** 2

**Parent:** [[Soil Health and Management]]

## Relationships

- uses [[rice]]
- located_in [[India]]
- uses [[rice]]
- located_in [[India]]
