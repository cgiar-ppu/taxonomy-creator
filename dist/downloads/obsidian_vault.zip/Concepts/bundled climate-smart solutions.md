# bundled climate-smart solutions

integrated package of climate adaptation and mitigation practices for agriculture

**Frequency:** 3

**Parent:** [[Innovation Bundling and Packages]]

## Relationships

- uses [[climate risk profiling]]
- targets [[maize]]
- uses [[climate risk profiling]]
- targets [[maize]]
