# gender equality and social inclusion

strategy to ensure equitable participation of marginalized groups

**Frequency:** 2

**Parent:** [[Gender Transformative Approaches]]

## Relationships

- targets [[smallholder farmers]]
- targets [[smallholder farmers]]
- targets [[smallholder farmers]]
- targets [[smallholder farmers]]
