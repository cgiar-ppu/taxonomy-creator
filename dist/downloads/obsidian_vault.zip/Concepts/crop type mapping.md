# crop type mapping

remote sensing identification of agricultural land use patterns

**Frequency:** 2

**Parent:** [[Remote Sensing and Digital Monitoring]]

## Relationships

- uses [[random forest classification]]
- located_in [[Oaxaca]]
- uses [[random forest classification]]
- located_in [[Oaxaca]]

## Referenced By

- [[OlmoEarth]] uses this
- [[OlmoEarth]] uses this
