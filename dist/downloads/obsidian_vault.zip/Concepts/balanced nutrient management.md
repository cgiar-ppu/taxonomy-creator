# balanced nutrient management

optimized fertilizer application strategy to improve crop productivity and resource efficiency

**Frequency:** 1

**Parent:** [[Uncategorized]]


## Referenced By

- [[mechanized direct seeded rice]] uses this
- [[mechanized direct seeded rice]] uses this
