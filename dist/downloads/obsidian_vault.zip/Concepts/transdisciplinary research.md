# transdisciplinary research

problem-focused research approach that integrates knowledge from multiple disciplines and stakeholders

**Frequency:** 1

**Parent:** [[Systems and Transdisciplinary Research]]


## Referenced By

- [[CGIAR]] uses this
- [[CGIAR]] uses this
