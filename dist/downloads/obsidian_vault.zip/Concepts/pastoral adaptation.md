# pastoral adaptation

changes in pastoralist practices to cope with environmental and climate challenges

**Frequency:** 2

**Parent:** [[Landscape and Ecosystem Approaches]]


## Referenced By

- [[pastoralists]] uses this
- [[pastoralists]] uses this
