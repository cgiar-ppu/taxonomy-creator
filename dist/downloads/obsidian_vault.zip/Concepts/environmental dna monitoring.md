# environmental dna monitoring

biodiversity assessment using genetic material extracted from environmental samples

**Frequency:** 1

**Parent:** [[Remote Sensing and Digital Monitoring]]


## Referenced By

- [[TerraBio]] uses this
- [[TerraBio]] uses this
