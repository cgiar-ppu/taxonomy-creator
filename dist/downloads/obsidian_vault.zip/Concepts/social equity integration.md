# social equity integration

ensuring marginalized groups have equal access to resources and decision-making in development programs

**Frequency:** 3

**Parent:** [[Justice and Equity Frameworks]]


## Referenced By

- [[women farmers]] uses this
- [[multi-stakeholder engagement]] produces this
- [[women farmers]] uses this
- [[multi-stakeholder engagement]] produces this
