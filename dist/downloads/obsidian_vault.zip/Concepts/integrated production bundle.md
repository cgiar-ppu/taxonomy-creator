# integrated production bundle

coherent package of agronomic practices, inputs, and management recommendations for specific crops

**Frequency:** 4

**Parent:** [[Innovation Bundling and Packages]]

## Relationships

- targets [[barley]]
- located_in [[Uzbekistan]]
- targets [[barley]]
- located_in [[Uzbekistan]]
