# realized genetic gain

actual improvement in crop traits achieved through breeding over time

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]


## Referenced By

- [[speed breeding]] produces this
- [[groundnut]] uses this
- [[speed breeding]] produces this
- [[groundnut]] uses this
