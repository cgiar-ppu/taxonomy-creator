# participatory monitoring and evaluation

community-led approach to tracking progress and assessing outcomes using locally relevant indicators

**Frequency:** 3

**Parent:** [[Participatory Learning Methods]]


## Referenced By

- [[vision-to-action approach]] produces this
- [[multifunctional landscapes]] uses this
- [[vision-to-action approach]] produces this
- [[multifunctional landscapes]] uses this
