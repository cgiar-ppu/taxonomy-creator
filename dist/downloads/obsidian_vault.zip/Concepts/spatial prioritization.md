# spatial prioritization

geographic targeting based on spatial analysis

**Frequency:** 1

**Parent:** [[Remote Sensing and Earth Observation]]

