# crop intensification

increasing agricultural productivity per unit area through improved practices

**Frequency:** 2

**Parent:** [[Uncategorized]]

## Relationships

- uses [[short-duration aman rice]]
- uses [[short-duration aman rice]]
