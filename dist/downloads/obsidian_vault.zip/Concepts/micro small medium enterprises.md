# micro small medium enterprises

small-scale business entities that form the backbone of many developing economies

**Frequency:** 4

**Parent:** [[Business Development and Incubation]]

## Relationships

- targets [[food security]]
- targets [[food security]]
