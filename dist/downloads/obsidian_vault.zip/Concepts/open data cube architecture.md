# open data cube architecture

structured system for organizing and accessing large spatial datasets

**Frequency:** 1

**Parent:** [[Digital Platforms and Infrastructure]]

## Relationships

- located_in [[Limpopo River Basin]]
- located_in [[Limpopo River Basin]]

## Referenced By

- [[IWMI]] produces this
- [[IWMI]] produces this
