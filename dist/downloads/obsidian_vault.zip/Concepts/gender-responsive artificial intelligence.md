# gender-responsive artificial intelligence

ai systems designed to recognize and mitigate gender biases in service delivery

**Frequency:** 1

**Parent:** [[Responsible and Ethical Innovation]]

## Relationships

- targets [[smallholder farmers]]
- targets [[smallholder farmers]]

## Referenced By

- [[bias detection and mitigation]] addresses this
- [[bias detection and mitigation]] addresses this
