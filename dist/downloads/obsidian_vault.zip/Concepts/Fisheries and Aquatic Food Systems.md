# Fisheries and Aquatic Food Systems

Small-scale fisheries, aquatic food systems, and fisheries management

**Parent:** [[Aquaculture and Aquatic Food Systems]]

