# computable general equilibrium modeling

economic modeling approach for policy impact analysis

**Frequency:** 5

**Parent:** [[Mixed Methods and Qualitative Approaches]]

## Relationships

- targets [[policy researchers]]
- targets [[policy researchers]]

## Referenced By

- [[water-energy-food nexus]] uses this
- [[IFPRI]] uses this
- [[water-energy-food nexus]] uses this
- [[IFPRI]] uses this
