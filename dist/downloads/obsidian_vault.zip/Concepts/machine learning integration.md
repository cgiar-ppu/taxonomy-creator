# machine learning integration

combining machine learning algorithms with process-based models to improve agricultural predictions

**Frequency:** 1

**Parent:** [[Artificial Intelligence and Machine Learning]]

## Relationships

- uses [[crop suitability modeling]]
- uses [[crop suitability modeling]]
