# climate risk assessment

evaluation of climate hazard exposure and vulnerability

**Frequency:** 16

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- located_in [[Guatemala]]
- uses [[watershed modeling]]
- uses [[Africa Agriculture Adaptation Atlas]]
- uses [[CMIP6]]
- located_in [[Guatemala]]
- uses [[watershed modeling]]
- uses [[Africa Agriculture Adaptation Atlas]]
- uses [[CMIP6]]

## Referenced By

- [[climate adaptation planning]] addresses this
- [[vulnerability assessment]] uses this
- [[climate adaptation planning]] addresses this
- [[vulnerability assessment]] uses this
