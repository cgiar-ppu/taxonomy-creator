# pastoral mobility

traditional practice of moving livestock to access seasonal grazing resources

**Frequency:** 2

**Parent:** [[Landscape and Ecosystem Approaches]]

## Relationships

- addresses [[rangeland restoration]]
- addresses [[rangeland restoration]]
