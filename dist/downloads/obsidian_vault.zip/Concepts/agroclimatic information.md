# agroclimatic information

weather and climate data specifically relevant for agricultural decision-making

**Frequency:** 1

**Parent:** [[Climate Information Services]]

## Relationships

- located_in [[Guatemala]]
- located_in [[Guatemala]]
