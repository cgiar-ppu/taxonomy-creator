# image analysis

automated processing and interpretation of visual data

**Frequency:** 1

**Parent:** [[Core AI and ML Approaches]]

## Relationships

- targets [[rice]]
- targets [[rice]]

## Referenced By

- [[artificial intelligence]] uses this
- [[artificial intelligence]] uses this
