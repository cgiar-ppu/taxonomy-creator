# participatory breeding

involving farmers in variety selection and development process

**Frequency:** 11

**Parent:** [[Participatory Breeding and Variety Selection]]

## Relationships

- uses [[farmer feedback]]
- targets [[smallholder farmers]]
- uses [[triadic comparisons of technology options]]
- uses [[farmer feedback]]
- targets [[smallholder farmers]]
- uses [[triadic comparisons of technology options]]
