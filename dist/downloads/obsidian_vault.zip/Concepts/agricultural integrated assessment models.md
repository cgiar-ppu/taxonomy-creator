# agricultural integrated assessment models

quantitative models combining economic, crop growth, and hydrology components for food security analysis

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- addresses [[food security]]
- addresses [[food security]]
