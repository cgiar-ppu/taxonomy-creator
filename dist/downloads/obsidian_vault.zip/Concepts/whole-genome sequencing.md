# whole-genome sequencing

complete DNA analysis technique for pathogen identification and characterization

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]


## Referenced By

- [[genomic profiling]] uses this
- [[genomic profiling]] uses this
