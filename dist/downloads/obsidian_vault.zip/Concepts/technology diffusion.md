# technology diffusion

spread and adoption of new technologies across markets and users

**Frequency:** 3

**Parent:** [[South-South and Knowledge Exchange]]


## Referenced By

- [[agrodealers]] uses this
- [[human-centered design]] addresses this
- [[agrodealers]] uses this
- [[human-centered design]] addresses this
