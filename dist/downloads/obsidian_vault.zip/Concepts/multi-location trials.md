# multi-location trials

testing of crop varieties across multiple geographic locations for validation

**Frequency:** 1

**Parent:** [[Field and On-Farm Trials]]

## Relationships

- uses [[striga resistance]]
- uses [[striga resistance]]
