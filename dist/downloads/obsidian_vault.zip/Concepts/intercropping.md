# intercropping

growing multiple crop species simultaneously in the same field

**Frequency:** 7

**Parent:** [[Sustainable Intensification and Diversification]]

## Relationships

- uses [[grain legumes]]
- uses [[maize]]
- uses [[cowpea]]
- located_in [[Ghana]]
- targets [[smallholder farmer]]
- uses [[grain legumes]]
- uses [[maize]]
- uses [[cowpea]]
- located_in [[Ghana]]
- targets [[smallholder farmer]]

## Referenced By

- [[site-specific fertilizer recommendation]] uses this
- [[site-specific fertilizer recommendation]] uses this
