# floodwater management

strategies for controlling and utilizing flood waters for agricultural benefits

**Frequency:** 1

**Parent:** [[Irrigation and Water Infrastructure]]

## Relationships

- located_in [[Bangladesh]]
- located_in [[Bangladesh]]
