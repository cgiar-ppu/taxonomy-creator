# rapid generation advancement

techniques to reduce breeding cycle time and accelerate genetic gains

**Frequency:** 1

**Parent:** [[Crop Genetic Improvement]]


## Referenced By

- [[speed breeding]] uses this
- [[speed breeding]] uses this
