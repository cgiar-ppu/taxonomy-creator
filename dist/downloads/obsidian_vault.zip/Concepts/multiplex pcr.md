# multiplex pcr

molecular technique enabling simultaneous detection of multiple pathogens in one assay

**Frequency:** 1

**Parent:** [[Uncategorized]]

## Relationships

- targets [[Pantoea]]
- targets [[Pantoea]]
