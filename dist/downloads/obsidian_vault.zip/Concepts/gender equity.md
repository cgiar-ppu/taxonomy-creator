# gender equity

fair treatment and opportunities for all genders in agricultural systems

**Frequency:** 3

**Parent:** [[Gender Transformative Approaches]]

## Relationships

- targets [[coffee value chain]]
- targets [[coffee value chain]]
