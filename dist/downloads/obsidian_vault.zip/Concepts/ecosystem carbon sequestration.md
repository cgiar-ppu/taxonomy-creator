# ecosystem carbon sequestration

natural processes by which ecosystems capture and store atmospheric carbon

**Frequency:** 3

**Parent:** [[Specialized Analytical Techniques]]


## Referenced By

- [[zero-carbon agriculture]] uses this
- [[zero-carbon agriculture]] uses this
