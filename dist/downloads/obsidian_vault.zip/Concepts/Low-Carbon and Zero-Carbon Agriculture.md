# Low-Carbon and Zero-Carbon Agriculture

Low-emission and zero-carbon agricultural systems and practices

**Parent:** [[Climate Mitigation and Low-Carbon Agriculture]]

