# community conversations

structured dialogue approach for community engagement and behavior change

**Frequency:** 4

**Parent:** [[Training Modalities]]

## Relationships

- addresses [[antimicrobial resistance]]
- located_in [[Ethiopia]]
- targets [[pastoralist communities]]
- addresses [[one health]]
- addresses [[antimicrobial resistance]]
- located_in [[Ethiopia]]
- targets [[pastoralist communities]]
- addresses [[one health]]
