# Collective Action and Governance

Collective action and governance mechanisms for rural development

**Parent:** [[Institutional and Governance Frameworks]]

