# climate-conflict analysis

analytical approach to measure connections between climate change and conflict occurrence

**Frequency:** 1

**Parent:** [[Climate-Conflict Nexus]]

## Relationships

- uses [[Climate Security Observatory]]
- uses [[Climate Security Observatory]]
