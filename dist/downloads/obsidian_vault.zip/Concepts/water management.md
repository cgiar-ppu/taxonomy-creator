# water management

strategies for efficient use and conservation of water resources in agriculture

**Frequency:** 8

**Parent:** [[Water Governance and Management]]

## Relationships

- addresses [[climate risks]]
- addresses [[climate risks]]

## Referenced By

- [[AgWISE]] addresses this
- [[AgWISE]] addresses this
