# spatial analytics

analytical approaches combining geography, economics and data science for policy insights

**Frequency:** 1

**Parent:** [[Remote Sensing and Earth Observation]]

## Relationships

- targets [[policymakers]]
- targets [[policymakers]]
