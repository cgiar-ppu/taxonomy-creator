# disease and pest management

integrated strategies for controlling agricultural diseases and pests

**Frequency:** 2

**Parent:** [[Uncategorized]]

## Relationships

- targets [[potato]]
- targets [[potato]]
