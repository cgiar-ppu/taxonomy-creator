# polycentric governance

multi-level decision-making involving multiple centers of authority

**Frequency:** 1

**Parent:** [[Miscellaneous Methods and Approaches]]

## Relationships

- addresses [[transformative adaptation]]
- addresses [[transformative adaptation]]
