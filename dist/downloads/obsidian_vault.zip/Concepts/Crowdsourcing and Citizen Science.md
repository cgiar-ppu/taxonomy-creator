# Crowdsourcing and Citizen Science

Participatory and crowdsourced data collection

**Parent:** [[Precision Agriculture and Smart Farming]]

