# late blight resistance

plant trait providing protection against phytophthora infestans pathogen

**Frequency:** 1

**Parent:** [[Disease Management]]

## Relationships

- addresses [[yield losses]]
- addresses [[yield losses]]

## Referenced By

- [[3R-gene]] produces this
- [[3R-gene]] produces this
