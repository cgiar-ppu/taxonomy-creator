# multimodal advisory services

agricultural extension using multiple communication channels and formats

**Frequency:** 1

**Parent:** [[Digital Advisory and Extension]]

