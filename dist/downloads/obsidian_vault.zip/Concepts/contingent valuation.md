# contingent valuation

survey-based method to estimate economic value of non-market goods

**Frequency:** 2

**Parent:** [[Mixed Methods and Qualitative Approaches]]

## Relationships

- uses [[willingness to pay]]
- targets [[pastoralist]]
- uses [[willingness to pay]]
- targets [[pastoralist]]

## Referenced By

- [[ecosystem services valuation]] uses this
- [[ecosystem services valuation]] uses this
