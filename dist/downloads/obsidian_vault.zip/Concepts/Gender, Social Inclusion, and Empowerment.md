# Gender, Social Inclusion, and Empowerment

Gender-transformative approaches, social inclusion, and empowerment in agricultural knowledge systems

**Parent:** [[Capacity Development, Extension, and Knowledge Systems]]

