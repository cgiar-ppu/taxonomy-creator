# humanitarian response

coordinated assistance to populations affected by crises and disasters

**Frequency:** 2

**Parent:** [[Fragile and Conflict-Affected Settings]]

