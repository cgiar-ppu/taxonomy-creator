# farmer-led extension

agricultural advisory systems driven by peer-to-peer knowledge sharing among farmers

**Frequency:** 2

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- uses [[pioneer-positive deviance]]
- uses [[pioneer-positive deviance]]
