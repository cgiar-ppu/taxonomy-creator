# Pest, Disease, and Weed Management

Integrated pest management, biological control, disease resistance, and phytosanitary measures

**Parent:** [[Sustainable Farming Systems and Practices]]

