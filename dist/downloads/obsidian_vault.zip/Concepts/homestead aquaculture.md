# homestead aquaculture

small-scale fish farming practiced at household level for food security and income generation

**Frequency:** 2

**Parent:** [[Aquaculture Systems]]

## Relationships

- targets [[food security]]
- targets [[food security]]
