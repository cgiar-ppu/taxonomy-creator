# subsidy repurposing

redirecting government subsidy spending toward more effective development investments

**Frequency:** 1

**Parent:** [[Miscellaneous Methods and Approaches]]

## Relationships

- addresses [[agricultural productivity]]
- addresses [[agricultural productivity]]
