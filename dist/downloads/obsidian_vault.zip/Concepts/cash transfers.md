# cash transfers

direct monetary payments to individuals or households as social assistance

**Frequency:** 2

**Parent:** [[Social Protection in Fragile Contexts]]

## Relationships

- addresses [[intimate partner violence]]
- addresses [[intimate partner violence]]

## Referenced By

- [[ultra-poor graduation model]] uses this
- [[Transfer Modality Research Initiative]] uses this
- [[ultra-poor graduation model]] uses this
- [[Transfer Modality Research Initiative]] uses this
