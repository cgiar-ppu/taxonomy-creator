# quality assurance

systematic processes to ensure products or services meet specified standards

**Frequency:** 2

**Parent:** [[Miscellaneous Methods and Approaches]]

## Relationships

- addresses [[black soldier fly larvae]]
- addresses [[black soldier fly larvae]]
