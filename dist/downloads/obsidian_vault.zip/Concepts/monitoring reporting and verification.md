# monitoring reporting and verification

systematic tracking and validation of environmental and agricultural outcomes

**Frequency:** 1

**Parent:** [[MRV Frameworks]]


## Referenced By

- [[Rice GAPfinder]] uses this
- [[Rice GAPfinder]] uses this
