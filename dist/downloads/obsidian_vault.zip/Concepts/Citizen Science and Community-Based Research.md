# Citizen Science and Community-Based Research

Citizen science, community-based observation, and participatory climate services

**Parent:** [[Participatory Research and Co-Design]]

