# ecosystem service valuation

economic quantification of benefits provided by natural systems

**Frequency:** 1

**Parent:** [[Payment for Ecosystem Services]]

## Relationships

- located_in [[Medjerda watershed]]
- located_in [[Medjerda watershed]]
