# emissions monitoring

systematic measurement and verification of greenhouse gas emissions from agricultural activities

**Frequency:** 4

**Parent:** [[MRV Frameworks]]


## Referenced By

- [[climate finance mechanisms]] addresses this
- [[climate finance mechanisms]] addresses this
