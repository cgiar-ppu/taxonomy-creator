# direct-seeded rice

rice cultivation technique where seeds are sown directly in fields without transplanting

**Aliases:** direct seeded rice

**Frequency:** 28

**Parent:** [[Cropping Systems]]

## Relationships

- located_in [[Odisha]]
- addresses [[methane emissions]]
- located_in [[Cambodia]]
- located_in [[Vietnam]]
- part_of [[climate-smart agriculture]]
- produces [[water-use efficiency]]
- produces [[water-use efficiency]]
- addresses [[water scarcity]]
- located_in [[Odisha]]
- addresses [[methane emissions]]
- located_in [[Cambodia]]
- located_in [[Vietnam]]
- part_of [[climate-smart agriculture]]
- produces [[water-use efficiency]]
- produces [[water-use efficiency]]
- addresses [[water scarcity]]

## Referenced By

- [[conservation agriculture]] uses this
- [[conservation agriculture]] uses this
