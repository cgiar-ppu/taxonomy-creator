# automatic speech recognition

technology that converts spoken language into text for digital applications

**Frequency:** 3

**Parent:** [[Artificial Intelligence and Machine Learning]]

## Relationships

- targets [[smallholder farmers]]
- targets [[Bantu languages]]
- targets [[smallholder farmers]]
- targets [[Bantu languages]]

## Referenced By

- [[Longa]] uses this
- [[Longa]] uses this
