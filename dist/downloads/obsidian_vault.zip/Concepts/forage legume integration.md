# forage legume integration

incorporating protein-rich leguminous plants into livestock feeding systems

**Frequency:** 2

**Parent:** [[Feed and Forage Management]]

## Relationships

- located_in [[Kenya]]
- located_in [[Kenya]]

## Referenced By

- [[Crotalaria juncea]] is_a this
- [[Lablab purpureus]] is_a this
- [[Crotalaria juncea]] is_a this
- [[Lablab purpureus]] is_a this
