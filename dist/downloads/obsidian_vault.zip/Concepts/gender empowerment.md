# gender empowerment

process of increasing women's capacity to make strategic life choices

**Frequency:** 4

**Parent:** [[Gender Dynamics and Analysis]]


## Referenced By

- [[digital agriculture]] targets this
- [[digital agriculture]] targets this
