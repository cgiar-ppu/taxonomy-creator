# farmer-led innovation

innovation processes initiated and driven by farmers themselves

**Frequency:** 2

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- uses [[farmers handbook]]
- uses [[farmers handbook]]
