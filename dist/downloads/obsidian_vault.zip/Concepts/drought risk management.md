# drought risk management

strategies and systems to anticipate, prepare for, and respond to drought events

**Frequency:** 1

**Parent:** [[Climate Risk Assessment and Vulnerability]]

## Relationships

- located_in [[East Africa]]
- located_in [[East Africa]]
