# institutional learning

systematic knowledge acquisition and application within organizations

**Frequency:** 1

**Parent:** [[Governance Frameworks]]

## Relationships

- uses [[scaling champions]]
- uses [[scaling champions]]
