# Irrigation and Water Management

Water-saving irrigation technologies, water productivity, agricultural water management, and irrigation systems

**Parent:** [[Sustainable Farming Systems and Practices]]

