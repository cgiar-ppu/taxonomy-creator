# regional variety trials

multi-location testing of varieties across geographic regions

**Frequency:** 1

**Parent:** [[Field and On-Farm Trials]]

## Relationships

- located_in [[West Africa]]
- located_in [[West Africa]]
