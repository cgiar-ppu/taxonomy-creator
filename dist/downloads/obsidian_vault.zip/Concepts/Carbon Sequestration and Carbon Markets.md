# Carbon Sequestration and Carbon Markets

Carbon storage, accounting, and market mechanisms

**Parent:** [[Climate Mitigation and Low-Carbon Agriculture]]

