# multistakeholder platforms

collaborative mechanisms bringing together diverse actors to address common challenges

**Frequency:** 5

**Parent:** [[Multi-Stakeholder Platforms and Partnerships]]

## Relationships

- addresses [[value chain development]]
- located_in [[Cambodia]]
- addresses [[water governance]]
- located_in [[Nile Basin]]
- addresses [[value chain development]]
- located_in [[Cambodia]]
- addresses [[water governance]]
- located_in [[Nile Basin]]

## Referenced By

- [[Incomati Basin]] uses this
- [[Incomati Basin]] uses this
