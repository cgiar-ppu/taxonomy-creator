# spatial clustering

grouping of geographic units based on similarity of characteristics

**Frequency:** 1

**Parent:** [[Remote Sensing and Earth Observation]]

## Relationships

- uses [[geospatial analysis]]
- uses [[geospatial analysis]]
