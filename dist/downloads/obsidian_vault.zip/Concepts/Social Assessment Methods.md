# Social Assessment Methods

Methods for assessing social dimensions of agricultural interventions

**Parent:** [[Gender and Social Inclusion Methods]]

