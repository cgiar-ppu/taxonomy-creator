# food system analytics

data-driven analysis of food production, distribution, and consumption systems

**Frequency:** 3

**Parent:** [[Food Systems Transformation]]


## Referenced By

- [[anticipatory action]] addresses this
- [[anticipatory action]] addresses this
