# extension services

educational and advisory services that transfer knowledge and technologies to farmers

**Frequency:** 3

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- targets [[smallholder farmers]]
- targets [[smallholder farmers]]
