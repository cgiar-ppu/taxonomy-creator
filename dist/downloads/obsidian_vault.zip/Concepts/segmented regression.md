# segmented regression

statistical approach dividing data into segments for improved model fit

**Frequency:** 1

**Parent:** [[Uncategorized]]

## Relationships

- produces [[improved prediction accuracy]]
- produces [[improved prediction accuracy]]
