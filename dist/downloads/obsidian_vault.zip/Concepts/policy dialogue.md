# policy dialogue

structured discussions among stakeholders to inform policy development and implementation

**Frequency:** 2

**Parent:** [[Integrated and Adaptive Management]]

