# rust resistance

plant ability to defend against fungal rust pathogens

**Frequency:** 1

**Parent:** [[Disease Management]]


## Referenced By

- [[wheat]] related_to this
- [[wheat]] related_to this
