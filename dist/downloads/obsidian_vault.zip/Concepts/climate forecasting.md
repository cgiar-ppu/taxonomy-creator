# climate forecasting

prediction of future climate conditions to support agricultural and disaster preparedness planning

**Frequency:** 4

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- supports [[agricultural planning]]
- targets [[livestock nutrition management]]
- supports [[agricultural planning]]
- targets [[livestock nutrition management]]
