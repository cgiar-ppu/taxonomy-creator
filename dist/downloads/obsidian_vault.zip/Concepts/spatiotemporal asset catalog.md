# spatiotemporal asset catalog

standardized metadata specification for spatiotemporal data assets

**Frequency:** 1

**Parent:** [[Digital Platforms and Infrastructure]]


## Referenced By

- [[Open Data Cube]] uses this
- [[Open Data Cube]] uses this
