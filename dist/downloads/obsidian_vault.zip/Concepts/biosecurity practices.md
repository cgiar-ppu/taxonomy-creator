# biosecurity practices

preventive measures to reduce disease transmission in livestock production

**Frequency:** 2

**Parent:** [[Biosecurity and Disease Prevention]]

## Relationships

- located_in [[Kenya]]
- located_in [[Kenya]]
