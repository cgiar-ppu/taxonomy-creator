# market segmentation

division of markets based on consumer preferences and end-use requirements

**Frequency:** 11

**Parent:** [[Innovation Assessment and Bundling]]

## Relationships

- uses [[target product profiles]]
- targets [[smallholder farmer]]
- part_of [[target product profile]]
- targets [[taro]]
- uses [[target product profiles]]
- targets [[smallholder farmer]]
- part_of [[target product profile]]
- targets [[taro]]

## Referenced By

- [[spatial analysis]] uses this
- [[spatial analysis]] uses this
