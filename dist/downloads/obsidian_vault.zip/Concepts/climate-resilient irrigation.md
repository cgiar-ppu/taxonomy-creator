# climate-resilient irrigation

water management systems designed to withstand climate variability and change

**Frequency:** 1

**Parent:** [[Climate Resilience Building]]

## Relationships

- located_in [[Kenya]]
- located_in [[Kenya]]
