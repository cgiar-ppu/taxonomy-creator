# market linkages

connections between producers and buyers to facilitate trade

**Frequency:** 1

**Parent:** [[Agricultural Commercialization]]


## Referenced By

- [[digital platforms]] uses this
- [[digital platforms]] uses this
