# meta-qtl analysis

statistical method combining qtl data from multiple studies to identify consensus regions

**Frequency:** 1

**Parent:** [[Specialized Analytical Techniques]]

## Relationships

- uses [[peanut]]
- uses [[peanut]]
