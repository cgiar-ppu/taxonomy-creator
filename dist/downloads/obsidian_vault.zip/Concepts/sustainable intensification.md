# sustainable intensification

increasing agricultural productivity while maintaining environmental sustainability

**Frequency:** 5

**Parent:** [[Planetary and Environmental Sustainability]]

## Relationships

- produces [[job creation]]
- addresses [[food insecurity]]
- located_in [[Malawi]]
- produces [[job creation]]
- addresses [[food insecurity]]
- located_in [[Malawi]]

## Referenced By

- [[agricultural research for development]] produces this
- [[smallholder farmer]] uses this
- [[soil fertility management]] part_of this
- [[agricultural research for development]] produces this
- [[smallholder farmer]] uses this
- [[soil fertility management]] part_of this
