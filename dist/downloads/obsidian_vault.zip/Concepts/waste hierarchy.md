# waste hierarchy

prioritization framework emphasizing prevention, reduction, reuse, and recycling for waste management

**Frequency:** 1

**Parent:** [[Circular Economy Principles]]


## Referenced By

- [[circular economy]] addresses this
- [[circular economy]] addresses this
