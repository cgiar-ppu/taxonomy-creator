# multilocation trials

testing varieties across multiple sites to assess performance and adaptation

**Frequency:** 1

**Parent:** [[Field and On-Farm Trials]]

## Relationships

- located_in [[Madagascar]]
- located_in [[Madagascar]]
