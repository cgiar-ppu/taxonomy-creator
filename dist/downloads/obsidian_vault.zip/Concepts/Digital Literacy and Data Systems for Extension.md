# Digital Literacy and Data Systems for Extension

Digital literacy, data collection, and digital tools supporting extension and knowledge systems

**Parent:** [[Capacity Development, Extension, and Knowledge Systems]]

