# genomic marker development

creation of DNA-based tools for genetic analysis and tracking

**Frequency:** 1

**Parent:** [[Crop Genetic Improvement]]

## Relationships

- targets [[common bean]]
- targets [[common bean]]
