# low-carbon behaviors

individual and household actions that reduce greenhouse gas emissions

**Frequency:** 3

**Parent:** [[Behavior Change Approaches]]

## Relationships

- related_to [[digital literacy]]
- related_to [[digital literacy]]
