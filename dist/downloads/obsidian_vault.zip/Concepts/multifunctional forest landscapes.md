# multifunctional forest landscapes

forest areas managed to provide multiple ecosystem services and benefits simultaneously

**Frequency:** 1

**Parent:** [[Sustainable Land Management]]


## Referenced By

- [[behavioral nudges]] addresses this
- [[behavioral nudges]] addresses this
