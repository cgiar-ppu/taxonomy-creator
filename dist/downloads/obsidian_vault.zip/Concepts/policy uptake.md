# policy uptake

adoption and implementation of research findings in policy frameworks

**Frequency:** 3

**Parent:** [[Integrated and Adaptive Management]]

## Relationships

- located_in [[Nigeria]]
- located_in [[Nigeria]]
