# index insurance

insurance products that use objective indices to trigger payouts rather than individual loss assessments

**Frequency:** 3

**Parent:** [[Insurance and Risk Finance]]

## Relationships

- targets [[smallholder farmers]]
- located_in [[Togo]]
- uses [[satellite remote sensing]]
- targets [[smallholder farmers]]
- located_in [[Togo]]
- uses [[satellite remote sensing]]
