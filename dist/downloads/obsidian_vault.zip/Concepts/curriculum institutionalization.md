# curriculum institutionalization

formal integration of interdisciplinary courses into university academic programs

**Frequency:** 1

**Parent:** [[Training Modalities]]


## Referenced By

- [[Tribhuvan University]] uses this
- [[Tribhuvan University]] uses this
