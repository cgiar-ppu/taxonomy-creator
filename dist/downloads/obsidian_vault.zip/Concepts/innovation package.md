# innovation package

bundled set of technologies, practices and services designed to achieve specific outcomes

**Frequency:** 2

**Parent:** [[Innovation Bundling and Packages]]

## Relationships

- targets [[smallholder farmer]]
- targets [[smallholder farmer]]
