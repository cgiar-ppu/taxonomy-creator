# financial innovation

development of new financial products and services for agricultural value chains

**Frequency:** 1

**Parent:** [[Blended Finance and Investment]]

## Relationships

- targets [[smallholder farmer]]
- targets [[smallholder farmer]]
