# Remote Sensing and Earth Observation

Remote sensing and earth observation for monitoring

**Parent:** [[Monitoring, Reporting, and Verification]]

