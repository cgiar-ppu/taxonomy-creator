# cost-effectiveness analysis

economic evaluation comparing costs and outcomes of different interventions

**Frequency:** 2

**Parent:** [[Experimental and Evaluation Methods]]

## Relationships

- uses [[methane emission reduction]]
- uses [[methane emission reduction]]
