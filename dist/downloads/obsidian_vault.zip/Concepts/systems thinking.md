# systems thinking

holistic approach to understanding complex problems by examining interconnections and leverage points

**Frequency:** 2

**Parent:** [[Systems and Transdisciplinary Research]]

## Relationships

- uses [[participatory capacity building]]
- part_of [[aquatic food systems]]
- uses [[participatory capacity building]]
- part_of [[aquatic food systems]]
