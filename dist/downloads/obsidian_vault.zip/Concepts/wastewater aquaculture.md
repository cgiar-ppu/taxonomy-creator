# wastewater aquaculture

fish farming using treated or untreated wastewater as input

**Frequency:** 1

**Parent:** [[Uncategorized]]

## Relationships

- located_in [[East Kolkata Wetlands]]
- located_in [[East Kolkata Wetlands]]
