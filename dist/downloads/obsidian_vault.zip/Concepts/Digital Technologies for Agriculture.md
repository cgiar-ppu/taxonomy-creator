# Digital Technologies for Agriculture

Cross-cutting digital technologies and platforms for agricultural development

**Parent:** [[Other / Cross-cutting]]

