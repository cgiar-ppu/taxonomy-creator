# whole-farm innovation bundles

integrated packages of complementary technologies and practices for entire farming systems

**Frequency:** 3

**Parent:** [[Innovation Bundling and Packages]]

## Relationships

- addresses [[smallholder farmers]]
- addresses [[smallholder farmers]]

## Referenced By

- [[socio-technical innovation bundles]] part_of this
- [[responsible scaling]] uses this
- [[integrated catchment management]] part_of this
- [[socio-technical innovation bundles]] part_of this
- [[responsible scaling]] uses this
- [[integrated catchment management]] part_of this
