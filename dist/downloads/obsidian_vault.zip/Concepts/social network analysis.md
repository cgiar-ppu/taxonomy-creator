# social network analysis

analytical method to study information flow and relationships within social networks

**Frequency:** 1

**Parent:** [[Uncategorized]]

## Relationships

- located_in [[Senegal]]
- located_in [[Senegal]]
