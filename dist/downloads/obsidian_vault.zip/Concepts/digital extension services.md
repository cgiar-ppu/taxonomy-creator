# digital extension services

technology-enabled platforms for delivering agricultural advisory and information services to farmers

**Frequency:** 2

**Parent:** [[Digital Advisory and Extension]]

