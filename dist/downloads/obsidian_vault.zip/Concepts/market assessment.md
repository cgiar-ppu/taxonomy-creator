# market assessment

systematic evaluation of supply, demand, and market dynamics for specific products or sectors

**Frequency:** 3

**Parent:** [[Statistical and Quantitative Methods]]

## Relationships

- targets [[integrated multitrophic aquaculture]]
- targets [[integrated multitrophic aquaculture]]
