# gender-inclusive water management

water governance approaches that ensure equitable participation of women in decision-making

**Frequency:** 1

**Parent:** [[Gender Dynamics and Analysis]]

## Relationships

- located_in [[Okara District]]
- located_in [[Okara District]]

## Referenced By

- [[Water User Associations]] addresses this
- [[Water User Associations]] addresses this
